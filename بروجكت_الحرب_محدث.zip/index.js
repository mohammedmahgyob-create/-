const {
  Client, GatewayIntentBits, Partials, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  PermissionsBitField, ChannelType, StringSelectMenuBuilder,
  ModalBuilder, TextInputBuilder, TextInputStyle,
  ActivityType, REST, Routes, SlashCommandBuilder, Colors,
  MessageFlags
} = require('discord.js');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ════════════════════════════════════════════════════════════════════
//  CONFIG - دمج الإعدادات من الملفين
// ════════════════════════════════════════════════════════════════════
const CONFIG = {
  prefixes: ['$', '!'],
  owners: (process.env.BOT_OWNERS || '1515004170355212482').split(','),
  botOwner: process.env.BOT_OWNER || '1515004170355212482',
  mainServerId: process.env.MAIN_SERVER_ID || '1516068060606500874',
  logChannelId: process.env.LOG_CHANNEL_ID || '1517630727569801287',
  adminRoleId: process.env.ADMIN_ROLE_ID || '1516572466909282418',
  ticketCategoryId: process.env.TICKET_CATEGORY_ID || null,
  ticketPrefix: 'ticket-',
  dbFile: './data/kingdom.json',
  logsDir: './logs',
  startingCoins: 1000,
  startingGold: 10,
  salaryIntervalMs: 60 * 60 * 1000,
  maxAccumulationHours: 12,
  confirmCodeTTL: 5 * 60 * 1000,
  transferCooldownMs: 30 * 1000,
  protectionDuration: 5 * 60 * 1000,
  dailyCredits: 50,
  dailyStreakBonus: 10,
  creditToGoldRate: 100,
  creditToCoinRate: 1000,
  maxGoldPerPurchase: 10000,
  armyCost: 1000000,
  // ════ نظام عملة Vegon ════
  startingVegon: 50,               // عملة Vegon عند البداية
  vegonTransferCooldownMs: 60 * 1000, // كولداون تحويل Vegon (60 ثانية)
  vegonTransferFee: 0.02,          // رسوم التحويل 2%
  vegonVictoryReward: 10,          // مكافأة الانتصار
  vegonDefeatPenalty: 2,           // خسارة عند الهزيمة
  vegonDailyBonus: 5,              // مكافأة يومية
  vegonRaidReward: 3,              // مكافأة الغارة
  vegonAllianceBonus: 2,           // مكافأة التحالف
  coinsPerVegon: 5000,             // تحويل: 5000 عملة = 1 Vegon
  vegonPerCredit: 10,              // تحويل: 10 كريدت = 1 Vegon
  goldPerVegon: 2,                 // تحويل: 2 ذهب = 1 Vegon
  vegonAdminChannel: process.env.VEGON_LOG_CHANNEL || null
};

// ════════════════════════════════════════════════════════════════════
//  GAME DATA - دمج البيانات من كلا الملفين
// ════════════════════════════════════════════════════════════════════
const BUILDINGS = {
  farm: { name: '🌾 مزرعة', cost: 500, gold: 0, produces: { coins: 25 }, desc: 'تنتج عملات كل ساعة' },
  mine: { name: '⛏️ منجم', cost: 1500, gold: 0, produces: { coins: 60 }, desc: 'مصدر عملات أعلى' },
  goldmine: { name: '🏆 منجم ذهب', cost: 8000, gold: 5, produces: { gold: 1 }, desc: 'ينتج ذهب كل ساعة' },
  barracks: { name: '🏰 ثكنة', cost: 4000, gold: 0, produces: {}, desc: 'ضرورية لتجنيد الجنود' },
  wall: { name: '🧱 سور', cost: 3000, gold: 0, produces: {}, desc: '+10% دفاع' },
  tower: { name: '🗼 برج', cost: 6000, gold: 2, produces: {}, desc: '+15% دفاع' },
  market: { name: '🏪 سوق', cost: 5000, gold: 0, produces: { coins: 40 }, desc: 'تجارة إضافية' },
  academy: { name: '📚 أكاديمية', cost: 10000, gold: 5, produces: {}, desc: 'تفتح الترقيات' },
  hospital: { name: '🏥 مستشفى', cost: 7000, gold: 3, produces: {}, desc: 'يقلل خسائر الجنود' },
  castle: { name: '🏯 قلعة', cost: 25000, gold: 20, produces: { coins: 150 }, desc: 'مبنى ملكي قوي' }
};

const SOLDIERS = {
  recruit: { name: '🪖 مجند', cost: 100, gold: 0, attack: 3, defense: 2, upkeep: 1, requires: 'barracks' },
  archer: { name: '🏹 رامي', cost: 250, gold: 0, attack: 6, defense: 3, upkeep: 2, requires: 'barracks' },
  swordsman: { name: '⚔️ سياف', cost: 500, gold: 0, attack: 10, defense: 8, upkeep: 3, requires: 'barracks' },
  knight: { name: '🐎 فارس', cost: 1500, gold: 1, attack: 25, defense: 18, upkeep: 6, requires: 'academy' },
  mage: { name: '🧙 ساحر', cost: 3000, gold: 3, attack: 50, defense: 20, upkeep: 10, requires: 'academy' },
  dragon: { name: '🐉 تنين', cost: 15000, gold: 25, attack: 200, defense: 150, upkeep: 40, requires: 'castle' }
};

const UPGRADES = {
  attack1: { name: '⚔️ تدريب هجوم I', cost: 5000, gold: 2, effect: '+10% هجوم', requires: null },
  attack2: { name: '⚔️ تدريب هجوم II', cost: 15000, gold: 8, effect: '+25% هجوم', requires: 'attack1' },
  defense1: { name: '🛡️ تدريب دفاع I', cost: 5000, gold: 2, effect: '+10% دفاع', requires: null },
  defense2: { name: '🛡️ تدريب دفاع II', cost: 15000, gold: 8, effect: '+25% دفاع', requires: 'defense1' },
  economy1: { name: '💰 اقتصاد I', cost: 8000, gold: 3, effect: '+20% إنتاج', requires: null },
  economy2: { name: '💰 اقتصاد II', cost: 20000, gold: 10, effect: '+50% إنتاج', requires: 'economy1' },
  logistics: { name: '🚚 لوجستيات', cost: 12000, gold: 5, effect: '-25% صيانة', requires: null }
};

// متجر متقدم - من الملف الأول
function initShop() {
  return {
    categories: [
      { id: 'featured', name: '⭐ عروض مميزة', emoji: '⭐', color: 0xFF6B35 },
      { id: 'soldiers', name: '🪖 الجنود', emoji: '🪖', color: 0x3498DB },
      { id: 'buildings', name: '🏗️ المباني', emoji: '🏗️', color: 0x2ECC71 },
      { id: 'resources', name: '⛏️ الموارد', emoji: '⛏️', color: 0xF39C12 },
      { id: 'missiles', name: '🚀 الصواريخ', emoji: '🚀', color: 0xE74C3C },
      { id: 'defense', name: '🛡️ الدفاع', emoji: '🛡️', color: 0x1ABC9C },
      { id: 'special', name: '✨ مميزات خاصة', emoji: '✨', color: 0x9B59B6 },
      { id: 'cosmetics', name: '🎨 تجميلات', emoji: '🎨', color: 0xE91E63 },
      { id: 'boosters', name: '⚡ معززات', emoji: '⚡', color: 0x00BCD4 },
      { id: 'pets', name: '🐾 حيوانات', emoji: '🐾', color: 0x4CAF50 },
      { id: 'upgrades', name: '⬆️ الترقيات', emoji: '⬆️', color: 0x607D8B },
      { id: 'premium', name: '👑 مميزات بريميوم', emoji: '👑', color: 0xFFD700 }
    ],
    items: {
      starter_pack: {
        id: 'starter_pack', name: 'حزمة البداية', category: 'featured',
        price: 5000, priceCredit: 5, emoji: '🎁',
        desc: 'حزمة مميزة للمبتدئين: 50 جندي + 10 ضباط + قاعدة',
        stock: 50, soldiers: { جندي: 50, ضابط: 10 }, buildings: { قاعدة: true }
      },
      army_pack: {
        id: 'army_pack', name: 'حزمة الجيش', category: 'featured',
        price: 25000, priceCredit: 25, emoji: '⚔️',
        desc: 'حزمة جيش كاملة: 100 جندي + 20 ضابط + 5 عقيد + معسكر تدريب',
        stock: 20, soldiers: { جندي: 100, ضابط: 20, عقيد: 5 }, buildings: { معسكر_تدريب: true }
      },
      soldier: { id: 'soldier', name: 'جندي', category: 'soldiers', price: 3, priceCredit: 0, emoji: '🪖', desc: 'جندي عادي - قوة 5', power: 5, health: 20, stock: Infinity },
      officer: { id: 'officer', name: 'ضابط', category: 'soldiers', price: 10, priceCredit: 0, emoji: '🎖️', desc: 'ضابط محترف - قوة 10', power: 10, health: 35, stock: Infinity },
      colonel: { id: 'colonel', name: 'عقيد', category: 'soldiers', price: 25, priceCredit: 0, emoji: '🏅', desc: 'عقيد متمرس - قوة 15', power: 15, health: 40, stock: Infinity },
      general: { id: 'general', name: 'لواء', category: 'soldiers', price: 50, priceCredit: 0, emoji: '👑', desc: 'لواء اسطوري - قوة 25', power: 25, health: 50, stock: Infinity },
      elite: { id: 'elite', name: 'قوات خاصة', category: 'soldiers', price: 100, priceCredit: 0, emoji: '💀', desc: 'النخبة - قوة 50', power: 50, health: 100, stock: 100 },
      base: { id: 'base', name: 'قاعدة', category: 'buildings', price: 10000, priceCredit: 10, emoji: '🏢', desc: 'قاعدة عسكرية أساسية +500 صحة', stock: Infinity, defense: 50, hp: 500 },
      training: { id: 'training', name: 'معسكر تدريب', category: 'buildings', price: 100000, priceCredit: 100, emoji: '🏭', desc: 'لترقية الجنود', stock: Infinity, defense: 20 },
      walls: { id: 'walls', name: 'أسوار', category: 'buildings', price: 2000, priceCredit: 2, emoji: '🛡️', desc: 'حماية من الهجمات +30 دفاع', stock: Infinity, defense: 30, hp: 500 },
      mine: { id: 'mine', name: 'منجم', category: 'resources', price: 500000, priceCredit: 500, emoji: '⛏️', desc: 'دخل 2500-20000/ساعة', stock: 100, income: 10000 },
      oil: { id: 'oil', name: 'مستخرج نفط', category: 'resources', price: 1500000, priceCredit: 1500, emoji: '🛢️', desc: 'دخل 50000-200000/ساعة', stock: 50, income: 100000 },
      missile: { id: 'missile', name: 'صاروخ عادي', category: 'missiles', price: 5000, priceCredit: 5, emoji: '🚀', desc: 'يقتل 1-10 جنود - ضرر 50', stock: 500, damage: 50 },
      shield: { id: 'shield', name: 'درع حماية', category: 'defense', price: 50000, priceCredit: 50, emoji: '🛡️', desc: 'حماية لمدة 24 ساعة +100 دفاع', stock: 100, duration: 86400000, defense: 100 },
      doubleXP: { id: 'doubleXP', name: 'ضعف الخبرة', category: 'special', price: 25000, priceCredit: 25, emoji: '⭐', desc: 'ضعف الخبرة لمدة ساعة', stock: 200, duration: 3600000 },
      spy: { id: 'spy', name: 'جاسوس', category: 'special', price: 50000, priceCredit: 50, emoji: '🕵️', desc: 'يكشف معلومات العدو', stock: 30 },
      goldName: { id: 'goldName', name: 'اسم ذهبي', category: 'cosmetics', price: 100000, priceCredit: 100, emoji: '✨', desc: 'اسم ذهبي في القوائم', stock: Infinity },
      coinBooster: { id: 'coinBooster', name: 'معزز عملات', category: 'boosters', price: 75000, priceCredit: 75, emoji: '💰', desc: '20% زيادة في العملات لمدة يوم', stock: 50, duration: 86400000 },
      dog: { id: 'dog', name: 'كلب', category: 'pets', price: 50000, priceCredit: 50, emoji: '🐕', desc: '+5 قوة هجوم', stock: 50, attack: 5 },
      dragon: { id: 'dragon', name: 'تنين', category: 'pets', price: 500000, priceCredit: 500, emoji: '🐉', desc: '+50 قوة هجوم', stock: 5, attack: 50 },
      upgrade_attack: { id: 'upgrade_attack', name: 'ترقية هجوم', category: 'upgrades', price: 100000, priceCredit: 100, emoji: '⚔️', desc: '+5% قوة هجوم دائمة', stock: 10, attack: 5 },
      vip_membership: { id: 'vip_membership', name: 'عضوية VIP', category: 'premium', price: 500000, priceCredit: 500, emoji: '👑', desc: 'عضوية VIP لمدة شهر: +50% جميع الموارد', stock: 10, duration: 30 * 24 * 60 * 60 * 1000, boosters: { resource: 50, coin: 50, xp: 50 } }
    }
  };
}

// ════════════════════════════════════════════════════════════════════
//  DATABASE - دمج هيكل البيانات من الملفين
// ════════════════════════════════════════════════════════════════════
class Database {
  constructor() { this.load(); }

  load() {
    try {
      fs.mkdirSync(path.dirname(CONFIG.dbFile), { recursive: true });
      if (!fs.existsSync(CONFIG.dbFile)) {
        this.data = this.createNew();
        this.save();
        return;
      }
      this.data = JSON.parse(fs.readFileSync(CONFIG.dbFile, 'utf8'));
      this.data = this.ensureFields(this.data);
      this.save();
    } catch (e) {
      console.error('❌ DB load error:', e);
      this.data = this.createNew();
      this.save();
    }
  }

  createNew() {
    return {
      armies: {},
      alliances: {},
      wars: [],
      joinRequests: {},
      economy: { totalCoins: 0, totalCredits: 0, multiplier: 1.0 },
      pendingPayments: {},
      goldTransactions: [],
      logs: [],
      cooldowns: {},
      dailyRewards: {},
      duels: {},
      tournaments: { active: null, participants: {}, winners: [] },
      quests: { active: [], completed: {} },
      achievements: { all: [], unlocked: {} },
      pets: { all: [], owned: {} },
      market: { listings: [] },
      guilds: {},
      battlepass: { active: null, progress: {} },
      blacklist: [],
      votes: {},
      referrals: {},
      giftHistory: [],
      tickets: {},
      tempDiscount: {},
      discountCodes: {},
      shop: initShop(),
      pendingConfirms: {},
      vegonTransactions: []
    };
  }

  ensureFields(data) {
    const defaultData = this.createNew();
    for (const [key, value] of Object.entries(defaultData)) {
      if (!data[key]) data[key] = value;
    }
    if (!data.shop) data.shop = initShop();
    if (!data.tickets) data.tickets = {};
    if (!data.tempDiscount) data.tempDiscount = {};
    if (!data.discountCodes) data.discountCodes = {};
    if (!data.pendingConfirms) data.pendingConfirms = {};
    if (!data.vegonTransactions) data.vegonTransactions = [];
    // تأكد أن كل جيش عنده vegon
    for (const [uid, army] of Object.entries(data.armies || {})) {
      if (typeof army.vegon === 'undefined') army.vegon = CONFIG.startingVegon;
      if (!army.vegonLastTransfer) army.vegonLastTransfer = 0;
    }
    return data;
  }

  save() {
    try {
      fs.writeFileSync(CONFIG.dbFile, JSON.stringify(this.data, null, 2));
    } catch (e) { console.error('❌ DB save error:', e); }
  }

  getArmy(userId) {
    return this.data.armies[userId] || null;
  }

  createArmy(userId, name) {
    this.data.armies[userId] = {
      id: userId,
      name: name,
      coins: CONFIG.startingCoins,
      credits: 0,
      gold: CONFIG.startingGold,
      vegon: CONFIG.startingVegon,
      soldiers: {
        جندي: 100, ضابط: 0, عقيد: 0, لواء: 0,
        قناص: 0, طبيب: 0, مهندس: 0, قوات_خاصة: 0
      },
      buildings: {
        قاعدة: false, معسكر_تدريب: false, أسوار: false,
        دفاع_جوي: false, حصن: false, مستشفى: false,
        رادار: false, ملجأ: false
      },
      mines: 0, oilRigs: 0, farms: 0, factories: 0,
      goldMines: 0, lumber: 0,
      missiles: { عادي: 0, متوسط: 0, مدمر: 0, نووي: 0, emp: 0 },
      alliance: null, allianceRole: null,
      protected: false, protectedUntil: 0,
      lastAttack: 0, lastCollect: Date.now(),
      salaryDebt: 0,
      victories: 0, defeats: 0,
      level: 1, xp: 0, xpToNext: 100,
      createdAt: Date.now(),
      cosmetics: { goldName: false, glow: false, crown: false, frame: false, dark_mode: false, animated: false },
      boosters: { coin: 0, attack: 0, defense: 0, xp: 0, resource: 0 },
      shield: 0, shieldUntil: 0,
      dailyStreak: 0, lastDaily: 0,
      pets: [], achievements: [], quests: [],
      marketListings: [],
      guild: null, guildRole: null,
      duelStats: { wins: 0, losses: 0, draws: 0 },
      tournamentWins: 0,
      totalRaids: 0, totalAttacks: 0, totalDefenses: 0,
      totalCoinsEarned: 0, totalCreditsEarned: 0,
      referrals: [], referredBy: null,
      battlepass: { level: 0, xp: 0, claimed: [] },
      lastWork: 0,
      gambleStats: { wins: 0, losses: 0, totalBet: 0, totalWin: 0 },
      upgrades: { attack: 0, defense: 0, resource: 0, health: 0, speed: 0 },
      defenseBuildings: { walls: 0, bunker: 0, fortress: 0, radar: 0, shield_generator: 0, anti_missile: 0, minefield: 0 },
      baseHP: 1000, baseMaxHP: 1000,
      spies: 0, lastHeal: Date.now(),
      instantBuilds: 0,
      vip: false, vipUntil: 0,
      ticketChannelId: null
    };
    this.save();
    return this.data.armies[userId];
  }

  updateEconomy() {
    let totalCoins = 0, totalCredits = 0;
    for (const army of Object.values(this.data.armies)) {
      totalCoins += army.coins || 0;
      totalCredits += army.credits || 0;
    }
    this.data.economy.totalCoins = totalCoins;
    this.data.economy.totalCredits = totalCredits;
    this.save();
  }

  addLog(type, data) {
    const entry = { timestamp: Date.now(), type, ...data };
    this.data.logs.push(entry);
    if (this.data.logs.length > 10000) this.data.logs = this.data.logs.slice(-5000);
    this.save();
    try {
      if (!fs.existsSync(CONFIG.logsDir)) fs.mkdirSync(CONFIG.logsDir, { recursive: true });
      const date = new Date(entry.timestamp).toISOString().split('T')[0];
      const logFile = path.join(CONFIG.logsDir, `${date}.log`);
      fs.appendFileSync(logFile, `[${new Date(entry.timestamp).toISOString()}] ${entry.type}: ${JSON.stringify(entry)}\n`);
    } catch (e) { /* ignore */ }
  }
}

const db = new Database();

// ════════════════════════════════════════════════════════════════════
//  CLIENT
// ════════════════════════════════════════════════════════════════════
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Channel]
});

// ════════════════════════════════════════════════════════════════════
//  HELPERS - من الملف الأول مع إضافات
// ════════════════════════════════════════════════════════════════════
const fmt = n => Number(n || 0).toLocaleString('en-US');
const isAdmin = id => CONFIG.owners.includes(String(id));

function genConfirmCode() {
  return crypto.randomBytes(3).toString('hex').toUpperCase();
}

function formatNumber(num) {
  return num.toLocaleString();
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function calcPower(army) {
  let power = 0;
  const soldierTypes = {
    جندي: 5, ضابط: 10, عقيد: 15, لواء: 25,
    قناص: 35, طبيب: 5, مهندس: 8, قوات_خاصة: 50
  };
  for (const [type, count] of Object.entries(army.soldiers || {})) {
    power += count * (soldierTypes[type] || 0);
  }
  power *= (1 + (army.upgrades?.attack || 0) / 100);
  if (army.pets) {
    for (const petId of army.pets) {
      const pet = db.data.shop.items[petId];
      if (pet && pet.attack) power += pet.attack;
    }
  }
  if (army.vip) power *= 1.2;
  return Math.floor(power);
}

function calcDefense(army) {
  let defense = 0;
  const defenseMap = {
    قاعدة: 50, أسوار: 30, دفاع_جوي: 40,
    ملجأ: 100, حصن: 200, رادار: 20
  };
  for (const [building, built] of Object.entries(army.buildings || {})) {
    if (built && defenseMap[building]) defense += defenseMap[building];
  }
  if (army.defenseBuildings) {
    for (const [type, count] of Object.entries(army.defenseBuildings)) {
      if (type === 'shield_generator') defense += count * 300;
      else if (type === 'anti_missile') defense += count * 150;
      else if (type === 'minefield') defense += count * 80;
      else if (type === 'iron_wall') defense += count * 50;
      else if (type === 'walls') defense += count * 30;
    }
  }
  defense *= (1 + (army.upgrades?.defense || 0) / 100);
  if (army.pets) {
    for (const petId of army.pets) {
      const pet = db.data.shop.items[petId];
      if (pet && pet.defense) defense += pet.defense;
    }
  }
  if (army.vip) defense *= 1.2;
  return Math.floor(defense);
}

function totalSoldiers(army) {
  return Object.values(army.soldiers || {}).reduce((a, b) => a + b, 0);
}

function calcHourlySalary(army) {
  const salaries = { جندي: 0.5, ضابط: 1, عقيد: 3, لواء: 5, قناص: 4, طبيب: 2, مهندس: 3, قوات_خاصة: 10 };
  let total = 0;
  for (const [type, count] of Object.entries(army.soldiers || {})) {
    total += count * (salaries[type] || 0);
  }
  return total;
}

function isProtected(army) {
  return army.protected && Date.now() < army.protectedUntil;
}

function getLevel(xp) {
  return Math.floor(Math.sqrt(xp / 10)) + 1;
}

function getXpToNext(level) {
  return level * 100;
}

function getBaseHP(army) {
  let hp = army.baseHP || 1000;
  const maxHP = army.baseMaxHP || 1000;
  const healthUpgrade = (army.upgrades?.health || 0) / 100;
  return { hp, maxHP: Math.floor(maxHP * (1 + healthUpgrade)) };
}

function getResourceIncome(army) {
  let income = 0;
  const mineIncome = army.mines * randomInt(2500, 20000);
  const oilIncome = army.oilRigs * randomInt(50000, 200000);
  const farmIncome = (army.farms || 0) * randomInt(1000, 5000);
  const factoryIncome = (army.factories || 0) * randomInt(100000, 500000);
  const lumberIncome = (army.lumber || 0) * randomInt(500, 2000);
  const goldIncome = (army.goldMines || 0) * randomInt(1, 5);
  
  income = mineIncome + oilIncome + farmIncome + factoryIncome + lumberIncome;
  
  const boost = (army.boosters?.resource || 0) / 100;
  income *= (1 + boost);
  if (army.vip) income *= 1.5;
  
  return { income, goldIncome };
}

function applyItemToArmy(army, item, quantity) {
  switch (item.category) {
    case 'soldiers': {
      const typeMap = {
        'soldier': 'جندي', 'officer': 'ضابط', 'colonel': 'عقيد',
        'general': 'لواء', 'sniper': 'قناص', 'medic': 'طبيب',
        'engineer': 'مهندس', 'elite': 'قوات_خاصة'
      };
      const type = typeMap[item.id] || 'جندي';
      army.soldiers[type] = (army.soldiers[type] || 0) + quantity;
      break;
    }
    case 'buildings': {
      const buildMap = {
        'base': 'قاعدة', 'training': 'معسكر_تدريب', 'walls': 'أسوار',
        'aa': 'دفاع_جوي', 'bunker': 'ملجأ', 'fortress': 'حصن',
        'radar': 'رادار', 'hospital': 'مستشفى'
      };
      const buildName = buildMap[item.id];
      if (buildName) {
        army.buildings[buildName] = true;
        if (buildName === 'قاعدة') {
          army.baseMaxHP = (army.baseMaxHP || 1000) + 500;
          army.baseHP = army.baseMaxHP;
        }
      }
      break;
    }
    case 'resources': {
      if (item.id === 'mine') army.mines += quantity;
      else if (item.id === 'oil') army.oilRigs += quantity;
      else if (item.id === 'farm') army.farms = (army.farms || 0) + quantity;
      else if (item.id === 'factory') army.factories = (army.factories || 0) + quantity;
      else if (item.id === 'gold_mine') army.goldMines = (army.goldMines || 0) + quantity;
      else if (item.id === 'lumber') army.lumber = (army.lumber || 0) + quantity;
      break;
    }
    case 'missiles': {
      const missileMap = {
        'missile': 'عادي', 'missile_medium': 'متوسط',
        'missile_heavy': 'مدمر', 'missile_nuclear': 'نووي',
        'missile_emp': 'emp'
      };
      const missileType = missileMap[item.id];
      if (missileType) {
        army.missiles[missileType] = (army.missiles[missileType] || 0) + quantity;
      }
      break;
    }
    case 'defense': {
      if (item.id === 'shield') {
        army.shield = (army.shield || 0) + quantity;
      } else if (item.id === 'iron_wall' || item.id === 'shield_generator' || 
                 item.id === 'anti_missile' || item.id === 'minefield') {
        if (!army.defenseBuildings) army.defenseBuildings = {};
        army.defenseBuildings[item.id] = (army.defenseBuildings[item.id] || 0) + quantity;
      }
      break;
    }
    case 'special': {
      if (item.id === 'spy') {
        army.spies = (army.spies || 0) + quantity;
      } else if (item.id === 'doubleXP') {
        army.boosters.xp = (army.boosters.xp || 0) + 100;
      } else if (item.id === 'tripleCoins') {
        army.boosters.coin = (army.boosters.coin || 0) + 200;
      } else if (item.id === 'army_buff') {
        army.boosters.attack = (army.boosters.attack || 0) + 20;
        army.boosters.defense = (army.boosters.defense || 0) + 20;
      } else if (item.id === 'instantBuild') {
        army.instantBuilds = (army.instantBuilds || 0) + quantity;
      }
      break;
    }
    case 'cosmetics': {
      army.cosmetics[item.id] = true;
      break;
    }
    case 'boosters': {
      const boosterMap = {
        'coinBooster': 'coin', 'attackBooster': 'attack',
        'defenseBooster': 'defense', 'xpBooster': 'xp',
        'resourceBooster': 'resource'
      };
      const boosterType = boosterMap[item.id];
      if (boosterType) {
        army.boosters[boosterType] = (army.boosters[boosterType] || 0) + quantity * 60;
      }
      break;
    }
    case 'pets': {
      for (let i = 0; i < quantity; i++) {
        army.pets.push(item.id);
      }
      break;
    }
    case 'upgrades': {
      const upgradeMap = {
        'upgrade_attack': 'attack', 'upgrade_defense': 'defense',
        'upgrade_resource': 'resource', 'upgrade_health': 'health',
        'upgrade_speed': 'speed'
      };
      const upgradeType = upgradeMap[item.id];
      if (upgradeType) {
        army.upgrades[upgradeType] = (army.upgrades[upgradeType] || 0) + quantity;
      }
      break;
    }
    case 'featured': {
      if (item.soldiers) {
        for (const [type, count] of Object.entries(item.soldiers)) {
          army.soldiers[type] = (army.soldiers[type] || 0) + count * quantity;
        }
      }
      if (item.buildings) {
        for (const [build, value] of Object.entries(item.buildings)) {
          army.buildings[build] = true;
        }
      }
      if (item.gold) {
        army.gold = (army.gold || 0) + item.gold * quantity;
      }
      if (item.credits) {
        army.credits = (army.credits || 0) + item.credits * quantity;
      }
      break;
    }
    case 'premium': {
      if (item.soldiers) {
        for (const [type, count] of Object.entries(item.soldiers)) {
          army.soldiers[type] = (army.soldiers[type] || 0) + count * quantity;
        }
      }
      if (item.pets) {
        for (const pet of item.pets) {
          for (let i = 0; i < quantity; i++) {
            army.pets.push(pet);
          }
        }
      }
      if (item.upgrades) {
        for (const [up, value] of Object.entries(item.upgrades)) {
          army.upgrades[up] = (army.upgrades[up] || 0) + value * quantity;
        }
      }
      if (item.boosters) {
        for (const [booster, value] of Object.entries(item.boosters)) {
          army.boosters[booster] = (army.boosters[booster] || 0) + value * quantity;
        }
      }
      if (item.shield === Infinity) {
        army.protected = true;
        army.protectedUntil = Date.now() + 365 * 24 * 60 * 60 * 1000;
      }
      if (item.id === 'vip_membership') {
        army.vip = true;
        army.vipUntil = Date.now() + 30 * 24 * 60 * 60 * 1000;
      }
      break;
    }
  }
}

// ════════════════════════════════════════════════════════════════════
//  SLASH COMMANDS - دمج من الملف الأول
// ════════════════════════════════════════════════════════════════════
const slashCommands = [];

// الأساسيات
slashCommands.push(
  new SlashCommandBuilder()
    .setName('بدء')
    .setDescription('إنشاء جيش جديد')
    .addStringOption(option =>
      option.setName('الاسم')
        .setDescription('اسم الجيش')
        .setRequired(true)
        .setMinLength(2)
        .setMaxLength(30)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('ملفي')
    .setDescription('عرض معلومات جيشك')
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر لاعب لعرض ملفه')
        .setRequired(false)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('متجر')
    .setDescription('فتح المتجر الرسمي')
    .addStringOption(option =>
      option.setName('الفئة')
        .setDescription('اختر فئة من المتجر')
        .setRequired(false)
        .addChoices(
          { name: '⭐ عروض مميزة', value: 'featured' },
          { name: '🪖 الجنود', value: 'soldiers' },
          { name: '🏗️ المباني', value: 'buildings' },
          { name: '⛏️ الموارد', value: 'resources' },
          { name: '🚀 الصواريخ', value: 'missiles' },
          { name: '🛡️ الدفاع', value: 'defense' },
          { name: '✨ مميزات خاصة', value: 'special' },
          { name: '🎨 تجميلات', value: 'cosmetics' },
          { name: '⚡ معززات', value: 'boosters' },
          { name: '🐾 حيوانات', value: 'pets' },
          { name: '⬆️ الترقيات', value: 'upgrades' },
          { name: '👑 مميزات بريميوم', value: 'premium' }
        )
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('تذكرة')
    .setDescription('فتح تذكرة للشراء والتحويل')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('ذهب')
    .setDescription('شراء ذهب بالكريدت')
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('كمية الذهب المطلوبة')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(10000)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('كريدت')
    .setDescription('عرض رصيد الكريدت الخاص بك')
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر لاعب لعرض رصيده')
        .setRequired(false)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('تحويل')
    .setDescription('تحويل العملات والكريدت')
    .addStringOption(option =>
      option.setName('نوع')
        .setDescription('نوع التحويل')
        .setRequired(true)
        .addChoices(
          { name: '💰 عملات → كريدت', value: 'coins_to_credits' },
          { name: '💳 كريدت → عملات', value: 'credits_to_coins' },
          { name: '🥇 ذهب → كريدت', value: 'gold_to_credits' },
          { name: '💳 كريدت → ذهب', value: 'credits_to_gold' }
        )
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('الكمية المطلوب تحويلها')
        .setRequired(true)
        .setMinValue(1)
    )
);

// القتال
slashCommands.push(
  new SlashCommandBuilder()
    .setName('هجوم')
    .setDescription('هجوم على لاعب آخر')
    .addUserOption(option =>
      option.setName('الهدف')
        .setDescription('اختر الهدف')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('غارة')
    .setDescription('شن غارة على الوحوش')
    .addIntegerOption(option =>
      option.setName('عدد')
        .setDescription('عدد الغارات')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(100)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('مبارزة')
    .setDescription('تحدي لاعب آخر لمبارزة')
    .addUserOption(option =>
      option.setName('الخصم')
        .setDescription('اختر خصمك')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('الرهان')
        .setDescription('مبلغ الرهان')
        .setRequired(false)
        .setMinValue(100)
    )
);

// القوائم
slashCommands.push(
  new SlashCommandBuilder()
    .setName('توب')
    .setDescription('عرض أفضل اللاعبين')
    .addStringOption(option =>
      option.setName('نوع')
        .setDescription('نوع الترتيب')
        .setRequired(false)
        .addChoices(
          { name: '⚡ القوة', value: 'power' },
          { name: '💰 العملات', value: 'coins' },
          { name: '💳 الكريدت', value: 'credits' },
          { name: '🥇 الذهب', value: 'gold' },
          { name: '🏆 الانتصارات', value: 'victories' },
          { name: '📈 المستوى', value: 'level' }
        )
    )
);

// الموارد
slashCommands.push(
  new SlashCommandBuilder()
    .setName('جمع')
    .setDescription('جمع دخل الموارد')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('تدريب')
    .setDescription('ترقية الجنود')
    .addStringOption(option =>
      option.setName('نوع')
        .setDescription('نوع الجندي للترقية')
        .setRequired(true)
        .addChoices(
          { name: '🪖 جندي → ضابط', value: 'جندي' },
          { name: '🎖️ ضابط → عقيد', value: 'ضابط' },
          { name: '🏅 عقيد → لواء', value: 'عقيد' }
        )
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('عدد الجنود للترقية')
        .setRequired(true)
        .setMinValue(1)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('يومي')
    .setDescription('الحصول على مكافأة يومية')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('عمل')
    .setDescription('العمل لكسب عملات إضافية')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('شفاء')
    .setDescription('شفاء الجنود')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('جدار')
    .setDescription('بناء جدار دفاعي')
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('عدد الجدران')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(10)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('حماية')
    .setDescription('تفعيل درع الحماية')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('قاعدة')
    .setDescription('ترقية القاعدة')
);

// التجسس
slashCommands.push(
  new SlashCommandBuilder()
    .setName('تجسس')
    .setDescription('تجسس على لاعب')
    .addUserOption(option =>
      option.setName('الهدف')
        .setDescription('الهدف')
        .setRequired(true)
    )
);

// التحالفات
slashCommands.push(
  new SlashCommandBuilder()
    .setName('تحالف')
    .setDescription('إنشاء تحالف جديد')
    .addStringOption(option =>
      option.setName('الاسم')
        .setDescription('اسم التحالف')
        .setRequired(true)
        .setMinLength(2)
        .setMaxLength(30)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('انضمام')
    .setDescription('طلب الانضمام لتحالف')
    .addStringOption(option =>
      option.setName('التحالف')
        .setDescription('اسم التحالف')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('طلبات')
    .setDescription('عرض طلبات الانضمام')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('قبول')
    .setDescription('قبول طلب انضمام')
    .addUserOption(option =>
      option.setName('اللاعب')
        .setDescription('اللاعب المطلوب')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('رفض')
    .setDescription('رفض طلب انضمام')
    .addUserOption(option =>
      option.setName('اللاعب')
        .setDescription('اللاعب المطلوب')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('ترقية')
    .setDescription('ترقية عضو لمشرف')
    .addUserOption(option =>
      option.setName('اللاعب')
        .setDescription('اللاعب المطلوب')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('تخفيض')
    .setDescription('تخفيض مشرف لعضو')
    .addUserOption(option =>
      option.setName('اللاعب')
        .setDescription('اللاعب المطلوب')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('طرد')
    .setDescription('طرد عضو من التحالف')
    .addUserOption(option =>
      option.setName('اللاعب')
        .setDescription('اللاعب المطلوب')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('خروج')
    .setDescription('الخروج من التحالف')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('حذف_تحالف')
    .setDescription('حذف التحالف')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('تحالفات')
    .setDescription('عرض قائمة التحالفات')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('اعضاء')
    .setDescription('عرض أعضاء تحالفك')
);

// الحروب
slashCommands.push(
  new SlashCommandBuilder()
    .setName('حرب')
    .setDescription('إعلان الحرب على تحالف')
    .addStringOption(option =>
      option.setName('التحالف')
        .setDescription('اسم التحالف المستهدف')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('سلام')
    .setDescription('طلب السلام من تحالف')
    .addStringOption(option =>
      option.setName('التحالف')
        .setDescription('اسم التحالف')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('قبول_سلام')
    .setDescription('قبول طلب السلام')
    .addStringOption(option =>
      option.setName('التحالف')
        .setDescription('اسم التحالف')
        .setRequired(true)
    )
);

// أخرى
slashCommands.push(
  new SlashCommandBuilder()
    .setName('مساعدة')
    .setDescription('عرض قائمة الأوامر')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('مخزون')
    .setDescription('عرض مخزونك العسكري')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('اعطاء')
    .setDescription('إعطاء عملات أو جنود لشخص آخر')
    .addUserOption(option =>
      option.setName('اللاعب')
        .setDescription('اللاعب المستلم')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('نوع')
        .setDescription('نوع العطاء')
        .setRequired(true)
        .addChoices(
          { name: '💰 عملات', value: 'coins' },
          { name: '🪖 جنود', value: 'soldiers' },
          { name: '💳 كريدت', value: 'credits' },
          { name: '🥇 ذهب', value: 'gold' }
        )
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('الكمية')
        .setRequired(true)
        .setMinValue(1)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('اقتصاد')
    .setDescription('عرض حالة الاقتصاد')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('عروض')
    .setDescription('عرض العروض اليومية')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('كود')
    .setDescription('استخدام كود خصم')
    .addStringOption(option =>
      option.setName('الكود')
        .setDescription('كود الخصم')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('توصيات')
    .setDescription('توصيات مخصصة لجيشك')
);

// أوامر المشرفين
slashCommands.push(
  new SlashCommandBuilder()
    .setName('اضافة_عملات')
    .setDescription('إضافة عملات للاعب')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر اللاعب')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('كمية العملات')
        .setRequired(true)
        .setMinValue(1)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('اضافة_كريدت')
    .setDescription('إضافة كريدت للاعب')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر اللاعب')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('كمية الكريدت')
        .setRequired(true)
        .setMinValue(1)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('اضافة_ذهب')
    .setDescription('إضافة ذهب للاعب')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر اللاعب')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('كمية الذهب')
        .setRequired(true)
        .setMinValue(1)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('تأكيد_دفع')
    .setDescription('تأكيد طلب دفع')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addStringOption(option =>
      option.setName('الكود')
        .setDescription('كود الدفع')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('تصفير')
    .setDescription('تصفير جيش لاعب')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر اللاعب')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('تصفير_الكل')
    .setDescription('تصفير جميع الجيوش')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('اعلان')
    .setDescription('إرسال إعلان عام')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addStringOption(option =>
      option.setName('النص')
        .setDescription('نص الإعلان')
        .setRequired(true)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('سحب')
    .setDescription('إنشاء سحب/هدية')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addStringOption(option =>
      option.setName('الجائزة')
        .setDescription('الجائزة')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('الفائزين')
        .setDescription('عدد الفائزين')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(10)
    )
    .addIntegerOption(option =>
      option.setName('المدة')
        .setDescription('مدة السحب بالثواني')
        .setRequired(false)
        .setMinValue(10)
        .setMaxValue(300)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('حظر')
    .setDescription('حظر لاعب من البوت')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر اللاعب')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('سبب')
        .setDescription('سبب الحظر')
        .setRequired(false)
    )
);

// ════ أوامر Vegon ════
slashCommands.push(
  new SlashCommandBuilder()
    .setName('vegon')
    .setDescription('💎 عرض رصيد Vegon الخاص بك أو بشخص آخر')
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر اللاعب (اختياري)')
        .setRequired(false)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('تحويل_vegon')
    .setDescription('💎 تحويل Vegon لعضو آخر')
    .addUserOption(option =>
      option.setName('اللاعب')
        .setDescription('اختر العضو المستلم')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('كمية Vegon للتحويل')
        .setRequired(true)
        .setMinValue(1)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('صرف_vegon')
    .setDescription('💎 صرف Vegon مقابل عملات اللعبة')
    .addStringOption(option =>
      option.setName('نوع')
        .setDescription('نوع الصرف')
        .setRequired(true)
        .addChoices(
          { name: '💰 Vegon → عملات', value: 'vegon_to_coins' },
          { name: '💳 Vegon → كريدت', value: 'vegon_to_credits' },
          { name: '🥇 Vegon → ذهب', value: 'vegon_to_gold' },
          { name: '💰 عملات → Vegon', value: 'coins_to_vegon' },
          { name: '💳 كريدت → Vegon', value: 'credits_to_vegon' },
          { name: '🥇 ذهب → Vegon', value: 'gold_to_vegon' }
        )
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('الكمية')
        .setRequired(true)
        .setMinValue(1)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('توب_vegon')
    .setDescription('💎 قائمة أغنى اللاعبين بعملة Vegon')
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('اضافة_vegon')
    .setDescription('💎 [ادمن] إضافة Vegon لعضو')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر اللاعب')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('كمية Vegon')
        .setRequired(true)
        .setMinValue(1)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('خصم_vegon')
    .setDescription('💎 [ادمن] خصم Vegon من عضو')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر اللاعب')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('الكمية')
        .setDescription('كمية Vegon للخصم')
        .setRequired(true)
        .setMinValue(1)
    )
    .addStringOption(option =>
      option.setName('سبب')
        .setDescription('سبب الخصم')
        .setRequired(false)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('سجل_vegon')
    .setDescription('💎 عرض سجل معاملات Vegon')
    .addUserOption(option =>
      option.setName('لاعب')
        .setDescription('اختر اللاعب (اختياري)')
        .setRequired(false)
    )
);

slashCommands.push(
  new SlashCommandBuilder()
    .setName('vegon_info')
    .setDescription('💎 معلومات شاملة عن نظام عملة Vegon')
);

// ════════════════════════════════════════════════════════════════════
//  COMMAND HANDLERS - من الملف الأول
// ════════════════════════════════════════════════════════════════════

// ─── أمر البدء ───
async function handleStart(interaction) {
  const userId = interaction.user.id;
  const name = interaction.options.getString('الاسم');
  
  if (db.getArmy(userId)) {
    return interaction.reply({
      content: '❌ عندك جيش بالفعل! استخدم `/ملفي` لعرض معلوماتك.',
      flags: MessageFlags.Ephemeral
    });
  }

  const army = db.createArmy(userId, name);
  db.updateEconomy();
  db.addLog('army_create', { userId, name });

  const embed = new EmbedBuilder()
    .setColor(0x2ECC71)
    .setTitle('🎉 أهلاً وسهلاً في لعبة الجيوش!')
    .setDescription(`**تم إنشاء جيش "${name}" بنجاح!**`)
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '🪖 الجنود', value: '**100 جندي مجاناً**', inline: true },
      { name: '💰 العملات', value: `**${CONFIG.startingCoins} عملة**`, inline: true },
      { name: '🏆 الذهب', value: `**${CONFIG.startingGold} ذهب**`, inline: true },
      { name: '📖 ابدأ هنا', value: '`/ملفي` — عرض جيشك\n`/غارة` — كسب عملات\n`/متجر` — قائمة المشتريات\n`/تذكرة` — فتح تذكرة للشراء', inline: false }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── أمر الملف الشخصي ───
async function handleProfile(interaction) {
  const targetUser = interaction.options.getUser('لاعب') || interaction.user;
  const army = db.getArmy(targetUser.id);

  if (!army) {
    return interaction.reply({
      content: targetUser.id === interaction.user.id ? 
        '❌ مش عندك جيش. استخدم `/بدء`' : 
        `❌ ${targetUser.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const power = calcPower(army);
  const defense = calcDefense(army);
  const total = totalSoldiers(army);
  const protected_ = isProtected(army);
  const level = getLevel(army.xp);
  const xpToNext = getXpToNext(level);
  const { hp, maxHP } = getBaseHP(army);

  const soldiersList = Object.entries(army.soldiers)
    .filter(([, c]) => c > 0)
    .map(([t, c]) => `${t}: ${formatNumber(c)}`)
    .join('\n') || 'مفيش جنود';

  const buildingsList = Object.entries(army.buildings)
    .filter(([, v]) => v)
    .map(([b]) => b)
    .join(' | ') || 'مفيش مباني';

  let title = `⚔️ جيش ${army.name}`;
  if (army.cosmetics?.goldName) title = `✨ ${title}`;
  if (army.cosmetics?.crown) title = `👑 ${title}`;
  if (army.vip) title = `💎 ${title}`;

  const embed = new EmbedBuilder()
    .setColor(army.cosmetics?.dark_mode ? 0x2C3E50 : 0xFFD700)
    .setTitle(title)
    .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
    .addFields(
      { name: '👤 المالك', value: `<@${army.id}>`, inline: true },
      { name: '💰 العملات', value: `**${formatNumber(army.coins)}**`, inline: true },
      { name: '💳 الكريدت', value: `**${formatNumber(army.credits || 0)}**`, inline: true },
      { name: '🏆 الذهب', value: `**${army.gold || 0}**`, inline: true },
      { name: '💎 Vegon', value: `**${army.vegon || 0} VGN**`, inline: true },
      { name: '⚡ القوة', value: `**${formatNumber(power)}**`, inline: true },
      { name: '🛡️ الدفاع', value: `**${formatNumber(defense)}**`, inline: true },
      { name: '🪖 الجنود', value: `**${formatNumber(total)}**`, inline: true },
      { name: '📈 المستوى', value: `**${level}** (${army.xp}/${xpToNext} XP)`, inline: true },
      { name: '👥 الجنود', value: soldiersList, inline: true },
      { name: '🏗️ المباني', value: buildingsList, inline: true },
      { name: '⛏️ المناجم', value: `**${army.mines}**`, inline: true },
      { name: '🛢️ النفط', value: `**${army.oilRigs}**`, inline: true },
      { name: '🏥 صحة القاعدة', value: `**${hp}/${maxHP}**`, inline: true },
      { name: '🛡️ الحماية', value: protected_ ? `✅ حتى <t:${Math.floor(army.protectedUntil / 1000)}:R>` : '❌ بلا حماية', inline: true },
      { name: '🏆 انتصارات/هزائم', value: `**${army.victories}/${army.defeats}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── المتجر ───
async function handleShop(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش. استخدم `/بدء`',
      flags: MessageFlags.Ephemeral
    });
  }

  const category = interaction.options.getString('الفئة');
  const shop = db.data.shop;
  const items = shop.items;

  if (category) {
    const categoryItems = Object.values(items).filter(item => item.category === category);
    const categoryInfo = shop.categories.find(c => c.id === category);
    
    if (!categoryItems.length) {
      return interaction.reply({
        content: `❌ مفيش عناصر في هذه الفئة.`,
        flags: MessageFlags.Ephemeral
      });
    }

    let description = `**💰 رصيدك: ${formatNumber(army.coins)} عملة | 💳 ${formatNumber(army.credits || 0)} كريدت**\n\n`;
    description += `**${categoryInfo?.emoji || '🛒'} ${categoryInfo?.name || category}**\n━━━━━━━━━━━━━━━━━━━━━━━━\n`;

    const sortedItems = categoryItems.sort((a, b) => (a.price || 0) - (b.price || 0));

    for (const item of sortedItems) {
      const priceCoin = item.price ? `💰 ${formatNumber(item.price)}` : '';
      const priceCredit = item.priceCredit ? `💳 ${formatNumber(item.priceCredit)}` : '';
      const stock = item.stock === Infinity ? '∞' : formatNumber(item.stock);
      const stockEmoji = item.stock === Infinity ? '♾️' : item.stock > 10 ? '🟢' : item.stock > 0 ? '🟡' : '🔴';
      
      description += `\n${item.emoji} **${item.name}**\n`;
      description += `└ 📝 ${item.desc}\n`;
      description += `└ 💰 ${priceCoin} ${priceCredit} | 📦 ${stockEmoji} ${stock}\n`;
      
      if (item.power) description += `└ ⚔️ القوة: +${item.power}\n`;
      if (item.defense) description += `└ 🛡️ الدفاع: +${item.defense}\n`;
      if (item.health) description += `└ ❤️ الصحة: +${item.health}\n`;
      if (item.duration) {
        const hours = Math.floor(item.duration / 3600000);
        description += `└ ⏱️ المدة: ${hours} ساعة\n`;
      }
      if (item.income) description += `└ 💰 الدخل: ${formatNumber(item.income)}/ساعة\n`;
    }

    const embed = new EmbedBuilder()
      .setColor(categoryInfo?.color || 0x3498DB)
      .setTitle(`${categoryInfo?.emoji || '🛒'} ${categoryInfo?.name || category}`)
      .setDescription(description)
      .setFooter({ text: 'اختر عنصر للشراء' });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId(`shop_buy_select_${category}`)
      .setPlaceholder('🎯 اختر العنصر للشراء')
      .addOptions(
        sortedItems.map(item => ({
          label: `${item.emoji} ${item.name}`.slice(0, 100),
          description: `${item.desc.substring(0, 50)}...`,
          value: item.id,
          emoji: item.emoji
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);
    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('shop_back_main')
        .setLabel('🔙 رجوع')
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({ embeds: [embed], components: [row, row2] });
    return;
  }

  // القائمة الرئيسية
  const embed = new EmbedBuilder()
    .setColor(0x3498DB)
    .setTitle('🏪 المتجر الرسمي للجيوش')
    .setDescription(`**💰 رصيدك: ${formatNumber(army.coins)} عملة | 💳 ${formatNumber(army.credits || 0)} كريدت**\n\nاختر فئة من القائمة`)
    .setThumbnail(client.user.displayAvatarURL())
    .addFields(
      shop.categories.map(cat => {
        const catItems = Object.values(items).filter(item => item.category === cat.id);
        const count = catItems.length;
        const cheapest = catItems.sort((a, b) => (a.price || 0) - (b.price || 0))[0];
        const cheapestPrice = cheapest ? `${formatNumber(cheapest.price || 0)}` : '0';
        return {
          name: `${cat.emoji} ${cat.name}`,
          value: `**${count} عنصر** | أقل سعر: ${cheapestPrice} عملة\nاستخدم \`/متجر ${cat.id}\``,
          inline: true
        };
      })
    )
    .setFooter({ text: '🛒 استخدم /متجر [الفئة] لعرض العناصر' });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('shop_ticket_open')
      .setLabel('🎫 فتح تذكرة شراء')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('shop_gold_buy')
      .setLabel('🏆 شراء ذهب')
      .setStyle(ButtonStyle.Primary)
  );

  await interaction.reply({ embeds: [embed], components: [row] });
}

// ─── فتح التذكرة ───
async function handleTicket(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (army.ticketChannelId) {
    const existingChannel = await client.channels.fetch(army.ticketChannelId).catch(() => null);
    if (existingChannel) {
      return interaction.reply({
        content: `✅ لديك تذكرة مفتوحة بالفعل: <#${army.ticketChannelId}>`,
        flags: MessageFlags.Ephemeral
      });
    }
    army.ticketChannelId = null;
    db.save();
  }

  const guild = interaction.guild;
  if (!guild) {
    return interaction.reply({
      content: '❌ لا يمكن استخدام التذكرة هنا.',
      flags: MessageFlags.Ephemeral
    });
  }

  const category = CONFIG.ticketCategoryId ? await guild.channels.fetch(CONFIG.ticketCategoryId).catch(() => null) : null;
  const channelName = `${CONFIG.ticketPrefix}${interaction.user.username}`;

  try {
    const channel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: category,
      permissionOverwrites: [
        { id: guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] },
        { id: client.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] }
      ]
    });

    army.ticketChannelId = channel.id;
    db.save();

    const embed = new EmbedBuilder()
      .setColor(0x9B59B6)
      .setTitle('🎫 تذكرة الشراء والتحويل')
      .setDescription(`مرحباً ${interaction.user.username}!\nاستخدم الأزرار أدناه للشراء أو التحويل.`)
      .addFields(
        { name: '💰 العملات', value: `**${formatNumber(army.coins)}**`, inline: true },
        { name: '💳 الكريدت', value: `**${formatNumber(army.credits || 0)}**`, inline: true },
        { name: '🏆 الذهب', value: `**${army.gold || 0}**`, inline: true }
      )
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket_buy').setLabel('🛒 شراء').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('ticket_convert').setLabel('💱 تحويل').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('ticket_close').setLabel('🔒 إغلاق التذكرة').setStyle(ButtonStyle.Danger)
    );

    await channel.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] });

    await interaction.reply({
      content: `✅ تم فتح تذكرة: <#${channel.id}>`,
      flags: MessageFlags.Ephemeral
    });

  } catch (error) {
    console.error('❌ خطأ في إنشاء التذكرة:', error);
    await interaction.reply({
      content: '❌ حدث خطأ في إنشاء التذكرة.',
      flags: MessageFlags.Ephemeral
    });
  }
}

// ─── معالج التذكرة ───
async function handleTicketInteraction(interaction) {
  if (!interaction.isButton()) return;
  if (!interaction.customId.startsWith('ticket_')) return;

  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (interaction.customId === 'ticket_close') {
    const channel = interaction.channel;
    await interaction.reply({
      content: '🔒 جاري إغلاق التذكرة...',
      flags: MessageFlags.Ephemeral
    });

    setTimeout(async () => {
      try {
        await channel.delete();
        army.ticketChannelId = null;
        db.save();
      } catch (e) {
        console.error('❌ خطأ في حذف التذكرة:', e);
      }
    }, 5000);
    return;
  }

  if (interaction.customId === 'ticket_buy') {
    const items = db.data.shop.items;
    const categories = db.data.shop.categories;

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('🛒 شراء')
      .setDescription('اختر الفئة ثم العنصر للشراء')
      .addFields(
        categories.map(cat => {
          const catItems = Object.values(items).filter(item => item.category === cat.id);
          return {
            name: `${cat.emoji} ${cat.name}`,
            value: `**${catItems.length} عنصر**`,
            inline: true
          };
        })
      )
      .setFooter({ text: 'اختر من القائمة المنسدلة' });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('ticket_buy_category')
      .setPlaceholder('🎯 اختر الفئة')
      .addOptions(
        categories.map(cat => ({
          label: `${cat.emoji} ${cat.name}`.slice(0, 100),
          description: `عرض عناصر ${cat.name}`,
          value: cat.id,
          emoji: cat.emoji
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);
    await interaction.update({ embeds: [embed], components: [row] });
    return;
  }

  if (interaction.customId === 'ticket_convert') {
    const embed = new EmbedBuilder()
      .setColor(0xF39C12)
      .setTitle('💱 تحويل العملات')
      .setDescription('اختر نوع التحويل')
      .addFields(
        { name: '💰 عملات → كريدت', value: `${formatNumber(CONFIG.creditToCoinRate)} عملة = 1 كريدت`, inline: true },
        { name: '💳 كريدت → عملات', value: `1 كريدت = ${formatNumber(CONFIG.creditToCoinRate)} عملة`, inline: true },
        { name: '🏆 ذهب → كريدت', value: `1 ذهب = ${formatNumber(CONFIG.creditToGoldRate)} كريدت`, inline: true },
        { name: '💳 كريدت → ذهب', value: `${formatNumber(CONFIG.creditToGoldRate)} كريدت = 1 ذهب`, inline: true }
      );

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('ticket_convert_type')
      .setPlaceholder('🎯 اختر نوع التحويل')
      .addOptions([
        { label: 'عملات → كريدت', value: 'coins_to_credits', emoji: '💰' },
        { label: 'كريدت → عملات', value: 'credits_to_coins', emoji: '💳' },
        { label: 'ذهب → كريدت', value: 'gold_to_credits', emoji: '🏆' },
        { label: 'كريدت → ذهب', value: 'credits_to_gold', emoji: '💳' }
      ]);

    const row = new ActionRowBuilder().addComponents(selectMenu);
    await interaction.update({ embeds: [embed], components: [row] });
    return;
  }

  if (interaction.customId === 'ticket_buy_category') {
    const category = interaction.values[0];
    const items = Object.values(db.data.shop.items).filter(item => item.category === category);
    const categoryInfo = db.data.shop.categories.find(c => c.id === category);

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle(`${categoryInfo?.emoji || '🛒'} ${categoryInfo?.name || category}`)
      .setDescription('اختر العنصر الذي تريد شراءه')
      .setFooter({ text: 'اختر من القائمة المنسدلة' });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('ticket_buy_item')
      .setPlaceholder('🎯 اختر العنصر')
      .addOptions(
        items.map(item => ({
          label: `${item.emoji} ${item.name}`.slice(0, 100),
          description: `${item.desc.substring(0, 50)}... | ${item.price ? `💰${item.price}` : ''}`,
          value: item.id,
          emoji: item.emoji
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);
    await interaction.update({ embeds: [embed], components: [row] });
    return;
  }

  if (interaction.customId === 'ticket_buy_item') {
    const itemId = interaction.values[0];
    const item = db.data.shop.items[itemId];
    if (!item) {
      return interaction.reply({
        content: '❌ عنصر غير موجود.',
        flags: MessageFlags.Ephemeral
      });
    }

    const modal = new ModalBuilder()
      .setCustomId(`ticket_buy_modal_${itemId}`)
      .setTitle(`🛒 شراء ${item.name}`)
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('quantity')
            .setLabel('الكمية المطلوبة')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('أدخل الكمية (مثال: 5)')
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(10)
        )
      );

    await interaction.showModal(modal);
    return;
  }

  if (interaction.customId === 'ticket_convert_type') {
    const type = interaction.values[0];
    
    const modal = new ModalBuilder()
      .setCustomId(`ticket_convert_modal_${type}`)
      .setTitle('💱 تحويل')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('amount')
            .setLabel('الكمية')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('أدخل الكمية')
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(10)
        )
      );

    await interaction.showModal(modal);
    return;
  }
}

// ─── معالج مودال التذكرة ───
async function handleTicketModal(interaction) {
  if (!interaction.isModalSubmit()) return;

  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (interaction.customId.startsWith('ticket_buy_modal_')) {
    const itemId = interaction.customId.replace('ticket_buy_modal_', '');
    const item = db.data.shop.items[itemId];
    if (!item) {
      return interaction.reply({
        content: '❌ عنصر غير موجود.',
        flags: MessageFlags.Ephemeral
      });
    }

    const quantity = parseInt(interaction.fields.getTextInputValue('quantity'));
    if (isNaN(quantity) || quantity < 1) {
      return interaction.reply({
        content: '❌ كمية غير صحيحة.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (item.stock !== Infinity && quantity > item.stock) {
      return interaction.reply({
        content: `❌ المخزون غير كافٍ. متاح ${formatNumber(item.stock)} فقط.`,
        flags: MessageFlags.Ephemeral
      });
    }

    let price = (item.price || 0) * quantity;
    let priceCredit = (item.priceCredit || 0) * quantity;

    const tempDiscount = db.data.tempDiscount;
    if (tempDiscount && tempDiscount.userId === interaction.user.id && Date.now() < tempDiscount.expiresAt) {
      const discount = tempDiscount.discount;
      price = Math.floor(price * (1 - discount / 100));
      priceCredit = Math.floor(priceCredit * (1 - discount / 100));
      delete db.data.tempDiscount;
      db.save();
    }

    if (price > 0 && army.coins < price) {
      return interaction.reply({
        content: `❌ مش عندك عملات كافية. محتاج ${formatNumber(price)} عملة.`,
        flags: MessageFlags.Ephemeral
      });
    }

    if (priceCredit > 0 && (army.credits || 0) < priceCredit) {
      return interaction.reply({
        content: `❌ مش عندك كريدت كافي. محتاج ${formatNumber(priceCredit)} كريدت.`,
        flags: MessageFlags.Ephemeral
      });
    }

    army.coins -= price;
    army.credits = (army.credits || 0) - priceCredit;

    if (item.stock !== Infinity) {
      item.stock -= quantity;
    }

    applyItemToArmy(army, item, quantity);

    db.updateEconomy();
    db.addLog('ticket_buy', { userId: interaction.user.id, item: itemId, quantity, price, priceCredit });

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('✅ تم الشراء بنجاح! 🎉')
      .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '📦 العنصر', value: `${item.emoji} **${item.name}** x${quantity}`, inline: true },
        { name: '💰 التكلفة', value: price > 0 ? `${formatNumber(price)} عملة` : 'مجاني', inline: true },
        { name: '💳 الكريدت', value: priceCredit > 0 ? `${formatNumber(priceCredit)} كريدت` : '0', inline: true },
        { name: '💼 رصيدك المتبقي', value: `💰 ${formatNumber(army.coins)} | 💳 ${formatNumber(army.credits || 0)}`, inline: false }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
    return;
  }

  if (interaction.customId.startsWith('ticket_convert_modal_')) {
    const type = interaction.customId.replace('ticket_convert_modal_', '');
    const amount = parseInt(interaction.fields.getTextInputValue('amount'));
    
    if (isNaN(amount) || amount < 1) {
      return interaction.reply({
        content: '❌ كمية غير صحيحة.',
        flags: MessageFlags.Ephemeral
      });
    }

    let result = '';
    let success = false;

    switch (type) {
      case 'coins_to_credits': {
        if (army.coins < amount) {
          return interaction.reply({
            content: `❌ مش عندك عملات كافية. عندك ${formatNumber(army.coins)} عملة.`,
            flags: MessageFlags.Ephemeral
          });
        }
        const credits = Math.floor(amount / CONFIG.creditToCoinRate);
        army.coins -= amount;
        army.credits = (army.credits || 0) + credits;
        result = `✅ تم تحويل ${formatNumber(amount)} عملة → ${formatNumber(credits)} كريدت`;
        success = true;
        break;
      }
      case 'credits_to_coins': {
        if ((army.credits || 0) < amount) {
          return interaction.reply({
            content: `❌ مش عندك كريدت كافي. عندك ${formatNumber(army.credits || 0)} كريدت.`,
            flags: MessageFlags.Ephemeral
          });
        }
        const coins = amount * CONFIG.creditToCoinRate;
        army.credits -= amount;
        army.coins += coins;
        result = `✅ تم تحويل ${formatNumber(amount)} كريدت → ${formatNumber(coins)} عملة`;
        success = true;
        break;
      }
      case 'gold_to_credits': {
        if ((army.gold || 0) < amount) {
          return interaction.reply({
            content: `❌ مش عندك ذهب كافي. عندك ${army.gold || 0} ذهب.`,
            flags: MessageFlags.Ephemeral
          });
        }
        const credits = amount * CONFIG.creditToGoldRate;
        army.gold -= amount;
        army.credits = (army.credits || 0) + credits;
        result = `✅ تم تحويل ${formatNumber(amount)} ذهب → ${formatNumber(credits)} كريدت`;
        success = true;
        break;
      }
      case 'credits_to_gold': {
        if ((army.credits || 0) < amount) {
          return interaction.reply({
            content: `❌ مش عندك كريدت كافي. عندك ${formatNumber(army.credits || 0)} كريدت.`,
            flags: MessageFlags.Ephemeral
          });
        }
        const gold = Math.floor(amount / CONFIG.creditToGoldRate);
        if (gold < 1) {
          return interaction.reply({
            content: `❌ الكمية قليلة جداً. محتاج على الأقل ${CONFIG.creditToGoldRate} كريدت لشراء 1 ذهب.`,
            flags: MessageFlags.Ephemeral
          });
        }
        army.credits -= amount;
        army.gold = (army.gold || 0) + gold;
        result = `✅ تم تحويل ${formatNumber(amount)} كريدت → ${formatNumber(gold)} ذهب`;
        success = true;
        break;
      }
    }

    if (success) {
      db.updateEconomy();
      db.addLog('ticket_convert', { userId: interaction.user.id, type, amount, result });

      const embed = new EmbedBuilder()
        .setColor(0xF39C12)
        .setTitle('💱 تم التحويل بنجاح!')
        .setDescription(result)
        .addFields(
          { name: '💰 العملات', value: `**${formatNumber(army.coins)}**`, inline: true },
          { name: '💳 الكريدت', value: `**${formatNumber(army.credits || 0)}**`, inline: true },
          { name: '🏆 الذهب', value: `**${army.gold || 0}**`, inline: true }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    }
  }
}

// ─── شراء الذهب السريع ───
async function handleGold(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const amount = interaction.options.getInteger('الكمية');
  const cost = amount * CONFIG.creditToGoldRate;

  if ((army.credits || 0) < cost) {
    return interaction.reply({
      content: `❌ مش عندك كريدت كافي. محتاج ${formatNumber(cost)} كريدت. عندك ${formatNumber(army.credits || 0)}`,
      flags: MessageFlags.Ephemeral
    });
  }

  army.credits -= cost;
  army.gold = (army.gold || 0) + amount;
  db.updateEconomy();
  db.addLog('gold_purchase', { userId: interaction.user.id, amount, cost });

  const embed = new EmbedBuilder()
    .setColor(0xFFD700)
    .setTitle('🏆 تم شراء الذهب بنجاح!')
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '🏆 الكمية', value: `**${amount} ذهب**`, inline: true },
      { name: '💳 التكلفة', value: `**${formatNumber(cost)} كريدت**`, inline: true },
      { name: '💰 رصيدك المتبقي', value: `**${formatNumber(army.credits || 0)} كريدت**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الكريدت ───
async function handleCredits(interaction) {
  const targetUser = interaction.options.getUser('لاعب') || interaction.user;
  const army = db.getArmy(targetUser.id);

  if (!army) {
    return interaction.reply({
      content: targetUser.id === interaction.user.id ?
        '❌ مش عندك جيش.' :
        `❌ ${targetUser.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle(`💳 رصيد الكريدت`)
    .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '👤 اللاعب', value: `<@${targetUser.id}>`, inline: true },
      { name: '💳 الكريدت', value: `**${formatNumber(army.credits || 0)}**`, inline: true },
      { name: '🏆 الذهب', value: `**${army.gold || 0}**`, inline: true },
      { name: '💰 العملات', value: `**${formatNumber(army.coins)}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── التحويل ───
async function handleConvert(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const type = interaction.options.getString('نوع');
  const amount = interaction.options.getInteger('الكمية');

  let result = '';
  let success = false;

  switch (type) {
    case 'coins_to_credits': {
      if (army.coins < amount) {
        return interaction.reply({
          content: `❌ مش عندك عملات كافية. عندك ${formatNumber(army.coins)} عملة.`,
          flags: MessageFlags.Ephemeral
        });
      }
      const credits = Math.floor(amount / CONFIG.creditToCoinRate);
      army.coins -= amount;
      army.credits = (army.credits || 0) + credits;
      result = `🔄 تم تحويل ${formatNumber(amount)} عملة → ${formatNumber(credits)} كريدت`;
      success = true;
      break;
    }
    case 'credits_to_coins': {
      if ((army.credits || 0) < amount) {
        return interaction.reply({
          content: `❌ مش عندك كريدت كافي. عندك ${formatNumber(army.credits || 0)} كريدت.`,
          flags: MessageFlags.Ephemeral
        });
      }
      const coins = amount * CONFIG.creditToCoinRate;
      army.credits -= amount;
      army.coins += coins;
      result = `🔄 تم تحويل ${formatNumber(amount)} كريدت → ${formatNumber(coins)} عملة`;
      success = true;
      break;
    }
    case 'gold_to_credits': {
      if ((army.gold || 0) < amount) {
        return interaction.reply({
          content: `❌ مش عندك ذهب كافي. عندك ${army.gold || 0} ذهب.`,
          flags: MessageFlags.Ephemeral
        });
      }
      const credits = amount * CONFIG.creditToGoldRate;
      army.gold -= amount;
      army.credits = (army.credits || 0) + credits;
      result = `🔄 تم تحويل ${formatNumber(amount)} ذهب → ${formatNumber(credits)} كريدت`;
      success = true;
      break;
    }
    case 'credits_to_gold': {
      if ((army.credits || 0) < amount) {
        return interaction.reply({
          content: `❌ مش عندك كريدت كافي. عندك ${formatNumber(army.credits || 0)} كريدت.`,
          flags: MessageFlags.Ephemeral
        });
      }
      const gold = Math.floor(amount / CONFIG.creditToGoldRate);
      if (gold < 1) {
        return interaction.reply({
          content: `❌ الكمية قليلة جداً. محتاج على الأقل ${CONFIG.creditToGoldRate} كريدت لشراء 1 ذهب.`,
          flags: MessageFlags.Ephemeral
        });
      }
      army.credits -= amount;
      army.gold = (army.gold || 0) + gold;
      result = `🔄 تم تحويل ${formatNumber(amount)} كريدت → ${formatNumber(gold)} ذهب`;
      success = true;
      break;
    }
    default: {
      return interaction.reply({
        content: '❌ نوع تحويل غير صحيح.',
        flags: MessageFlags.Ephemeral
      });
    }
  }

  if (success) {
    db.updateEconomy();
    db.addLog('convert', { userId: interaction.user.id, type, amount });

    const embed = new EmbedBuilder()
      .setColor(0xF39C12)
      .setTitle('💱 تم التحويل بنجاح!')
      .setDescription(result)
      .addFields(
        { name: '💰 العملات', value: `**${formatNumber(army.coins)}**`, inline: true },
        { name: '💳 الكريدت', value: `**${formatNumber(army.credits || 0)}**`, inline: true },
        { name: '🏆 الذهب', value: `**${army.gold || 0}**`, inline: true }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
}

// ─── الهجوم ───
async function handleAttack(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('الهدف');
  if (target.id === interaction.user.id) {
    return interaction.reply({
      content: '❌ مينفعش تهاجم نفسك!',
      flags: MessageFlags.Ephemeral
    });
  }

  const defArmy = db.getArmy(target.id);
  if (!defArmy) {
    return interaction.reply({
      content: `❌ ${target.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (isProtected(defArmy)) {
    return interaction.reply({
      content: `🛡️ ${target.username} محمي دلوقتي!`,
      flags: MessageFlags.Ephemeral
    });
  }

  const defPower = calcDefense(defArmy);
  const atkPower = calcPower(army);

  if (defArmy.buildings.أسوار && defPower > 0) {
    const hasMissile = Object.values(army.missiles || {}).some(count => count > 0);
    if (!hasMissile) {
      return interaction.reply({
        content: '🧱 الهدف عنده أسوار! استخدم صاروخ لتحطيمها.',
        flags: MessageFlags.Ephemeral
      });
    }
  }

  if (atkPower === 0) {
    return interaction.reply({
      content: '❌ مش عندك جنود للهجوم!',
      flags: MessageFlags.Ephemeral
    });
  }

  const totalDefense = defPower * 0.7;
  const atkRoll = atkPower * (0.7 + Math.random() * 0.6);
  const defRoll = totalDefense * (0.7 + Math.random() * 0.6) + (defArmy.defenseBuildings?.walls || 0) * 10;
  const won = atkRoll > defRoll;

  let atkCasualties = 0;
  let defCasualties = 0;
  let stolen = 0;
  let damage = 0;

  if (won) {
    defCasualties = Math.floor((defPower * 0.05 * Math.random() + 1) + (defArmy.defenseBuildings?.minefield || 0) * 0.5);
    stolen = Math.floor(defArmy.coins * 0.2);
    army.coins += stolen;
    defArmy.coins -= stolen;
    army.victories++;
    defArmy.defeats++;
    defArmy.protected = true;
    defArmy.protectedUntil = Date.now() + CONFIG.protectionDuration;
    damage = Math.floor(defArmy.baseHP * 0.1);
    defArmy.baseHP = Math.max(0, (defArmy.baseHP || 1000) - damage);
    army.xp += Math.floor(defPower * 0.1) + 10;
    // مكافأة Vegon على الانتصار
    army.vegon = (army.vegon || 0) + CONFIG.vegonVictoryReward;
    defArmy.vegon = Math.max(0, (defArmy.vegon || 0) - CONFIG.vegonDefeatPenalty);
  } else {
    atkCasualties = Math.floor(atkPower * 0.05 * Math.random() + 1);
    army.defeats++;
    defArmy.victories++;
    defArmy.vegon = (defArmy.vegon || 0) + Math.floor(CONFIG.vegonVictoryReward / 2);
    army.vegon = Math.max(0, (army.vegon || 0) - CONFIG.vegonDefeatPenalty);
    army.protected = true;
    army.protectedUntil = Date.now() + CONFIG.protectionDuration;
    army.xp += 5;
  }

  let rem = atkCasualties;
  for (const type of ['جندي', 'قناص', 'ضابط', 'عقيد', 'لواء', 'قوات_خاصة']) {
    if (rem <= 0) break;
    const lost = Math.min(army.soldiers[type] || 0, rem);
    army.soldiers[type] -= lost;
    rem -= lost;
  }

  const medics = army.soldiers.طبيب || 0;
  if (medics > 0 && atkCasualties > 0) {
    const healAmount = Math.min(medics * 2, atkCasualties);
    atkCasualties -= healAmount;
    army.soldiers.طبيب = (army.soldiers.طبيب || 0) + healAmount;
  }

  rem = defCasualties;
  for (const type of ['جندي', 'قناص', 'ضابط', 'عقيد', 'لواء', 'قوات_خاصة']) {
    if (rem <= 0) break;
    const lost = Math.min(defArmy.soldiers[type] || 0, rem);
    defArmy.soldiers[type] -= lost;
    rem -= lost;
  }

  db.updateEconomy();
  db.addLog('attack', { attacker: interaction.user.id, defender: target.id, won, atkCasualties, defCasualties, stolen, damage });

  const embed = new EmbedBuilder()
    .setColor(won ? 0x2ECC71 : 0xE74C3C)
    .setTitle(won ? `⚔️ انتصرت على ${defArmy.name}! 🎉` : `⚔️ اتهزمت قدام ${defArmy.name} 😔`)
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '💀 خسائرك', value: `**${atkCasualties} جندي**`, inline: true },
      { name: '💀 خسائر العدو', value: `**${defCasualties} جندي**`, inline: true },
      { name: won ? '💰 غنائم' : '😔 النتيجة', value: won ? `**+${formatNumber(stolen)} عملة**` : '**هزيمة**', inline: true },
      { name: '📊 قوتك', value: `**${formatNumber(atkPower)}**`, inline: true },
      { name: '📊 دفاع العدو', value: `**${formatNumber(totalDefense)}**`, inline: true },
      { name: '🏥 صحة القاعدة', value: `**${defArmy.baseHP || 0}/${defArmy.baseMaxHP || 1000}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الغارة ───
async function handleRaid(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const times = interaction.options.getInteger('عدد') || 1;
  const total = totalSoldiers(army);

  if (total < 1) {
    return interaction.reply({
      content: '❌ مش عندك جنود للغارة!',
      flags: MessageFlags.Ephemeral
    });
  }

  let earned = 0;
  let casualties = 0;
  let goldEarned = 0;

  for (let i = 0; i < times; i++) {
    earned += randomInt(10, 50);
    if (Math.random() < 0.1) goldEarned += randomInt(0, 1);
    if (Math.random() < 0.15) {
      casualties += randomInt(1, 3);
    }
  }

  const boost = (army.boosters?.resource || 0) / 100;
  earned *= (1 + boost);
  if (army.vip) earned *= 1.5;

  let rem = casualties;
  for (const type of ['جندي', 'قناص', 'ضابط', 'عقيد', 'لواء', 'قوات_خاصة']) {
    if (rem <= 0) break;
    const lost = Math.min(army.soldiers[type] || 0, rem);
    army.soldiers[type] -= lost;
    rem -= lost;
  }

  army.coins += Math.floor(earned);
  army.gold = (army.gold || 0) + goldEarned;
  army.totalRaids += times;
  army.xp += times * 2;
  // مكافأة Vegon من الغارات
  const vegonFromRaid = Math.floor(times * CONFIG.vegonRaidReward * Math.random()) + (times > 0 ? 1 : 0);
  army.vegon = (army.vegon || 0) + vegonFromRaid;
  db.updateEconomy();
  db.addLog('raid', { userId: interaction.user.id, times, earned, casualties, goldEarned, vegonEarned: vegonFromRaid });

  const embed = new EmbedBuilder()
    .setColor(casualties > 0 ? 0xE67E22 : 0x2ECC71)
    .setTitle(`⚔️ نتيجة ${times} غارة`)
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '💰 المكاسب', value: `**+${formatNumber(Math.floor(earned))} عملة**`, inline: true },
      { name: '🏆 الذهب', value: `**+${goldEarned}**`, inline: true },
      { name: '💎 Vegon', value: `**+${vegonFromRaid} VGN**`, inline: true },
      { name: '💀 الخسائر', value: `**${casualties} جندي**`, inline: true },
      { name: '💼 رصيدك الآن', value: `**${formatNumber(army.coins)}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── التوب ───
async function handleTop(interaction) {
  const type = interaction.options.getString('نوع') || 'power';
  const armies = Object.values(db.data.armies);

  if (!armies.length) {
    return interaction.reply({
      content: '❌ مفيش جيوش لسه.',
      flags: MessageFlags.Ephemeral
    });
  }

  let sorted = [];
  let title = '🏆 لوحة المتصدرين';

  switch (type) {
    case 'power':
      sorted = armies.sort((a, b) => calcPower(b) - calcPower(a));
      title = '⚡ أقوى 10 جيوش';
      break;
    case 'coins':
      sorted = armies.sort((a, b) => b.coins - a.coins);
      title = '💰 أغنى 10 جيوش';
      break;
    case 'credits':
      sorted = armies.sort((a, b) => (b.credits || 0) - (a.credits || 0));
      title = '💳 أغنى 10 جيوش بالكريدت';
      break;
    case 'gold':
      sorted = armies.sort((a, b) => (b.gold || 0) - (a.gold || 0));
      title = '🏆 أغنى 10 جيوش بالذهب';
      break;
    case 'victories':
      sorted = armies.sort((a, b) => b.victories - a.victories);
      title = '🏆 أكثر 10 جيوش انتصارات';
      break;
    case 'level':
      sorted = armies.sort((a, b) => getLevel(b.xp) - getLevel(a.xp));
      title = '📈 أعلى 10 جيوش مستوى';
      break;
    default:
      sorted = armies;
  }

  const top = sorted.slice(0, 10);
  const medals = ['🥇', '🥈', '🥉'];

  let description = '';
  for (let i = 0; i < top.length; i++) {
    const army = top[i];
    const medal = medals[i] || `**${i + 1}.**`;
    const user = await client.users.fetch(army.id).catch(() => null);
    const username = user ? user.username : army.id;
    
    let stat = '';
    switch (type) {
      case 'power': stat = `⚡ ${formatNumber(calcPower(army))}`; break;
      case 'coins': stat = `💰 ${formatNumber(army.coins)}`; break;
      case 'credits': stat = `💳 ${formatNumber(army.credits || 0)}`; break;
      case 'gold': stat = `🏆 ${army.gold || 0}`; break;
      case 'victories': stat = `🏆 ${army.victories}`; break;
      case 'level': stat = `📈 ${getLevel(army.xp)}`; break;
      default: stat = `⚡ ${formatNumber(calcPower(army))}`;
    }
    
    description += `${medal} **${army.name}** — ${stat} (${username})\n`;
  }

  const embed = new EmbedBuilder()
    .setColor(0xFFD700)
    .setTitle(title)
    .setDescription(description || 'مفيش بيانات')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الجمع ───
async function handleCollect(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const hasResources = army.mines > 0 || army.oilRigs > 0 || army.farms > 0 || 
                       army.factories > 0 || army.lumber > 0 || army.goldMines > 0;

  if (!hasResources) {
    return interaction.reply({
      content: '❌ مش عندك موارد. اشترِ من `/متجر`',
      flags: MessageFlags.Ephemeral
    });
  }

  const now = Date.now();
  const hours = Math.min((now - army.lastCollect) / 3600000, CONFIG.maxAccumulationHours);

  if (hours < 0.016) {
    return interaction.reply({
      content: '⏳ استنى شوية قبل الجمع تاني!',
      flags: MessageFlags.Ephemeral
    });
  }

  const { income, goldIncome } = getResourceIncome(army);
  const totalCoins = Math.floor(income * hours);
  const totalGold = Math.floor(goldIncome * hours);

  army.coins += totalCoins;
  army.gold = (army.gold || 0) + totalGold;
  army.lastCollect = now;
  db.updateEconomy();
  db.addLog('collect', { userId: interaction.user.id, totalCoins, totalGold });

  const embed = new EmbedBuilder()
    .setColor(0xF39C12)
    .setTitle('💰 تم جمع الدخل!')
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '⏱️ الفترة', value: `**${hours.toFixed(1)} ساعة**`, inline: true },
      { name: '💰 العملات', value: `**+${formatNumber(totalCoins)}**`, inline: true },
      { name: '🏆 الذهب', value: `**+${totalGold}**`, inline: true },
      { name: '💼 رصيدك الآن', value: `**${formatNumber(army.coins)}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── التدريب ───
async function handleTrain(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (!army.buildings.معسكر_تدريب) {
    return interaction.reply({
      content: '❌ محتاج معسكر تدريب! اشترِ من `/متجر`',
      flags: MessageFlags.Ephemeral
    });
  }

  const type = interaction.options.getString('نوع');
  const quantity = interaction.options.getInteger('الكمية');

  const trainingMap = {
    'جندي': { to: 'ضابط', cost: 2 },
    'ضابط': { to: 'عقيد', cost: 4 },
    'عقيد': { to: 'لواء', cost: 8 }
  };

  const training = trainingMap[type];
  if (!training) {
    return interaction.reply({
      content: '❌ نوع غير صحيح.',
      flags: MessageFlags.Ephemeral
    });
  }

  const available = army.soldiers[type] || 0;
  const actualQty = Math.min(quantity, available);

  if (actualQty < 1) {
    return interaction.reply({
      content: `❌ مش عندك ${type} للتدريب!`,
      flags: MessageFlags.Ephemeral
    });
  }

  const totalCost = training.cost * actualQty;
  if (army.coins < totalCost) {
    return interaction.reply({
      content: `❌ محتاج ${formatNumber(totalCost)} عملة. عندك ${formatNumber(army.coins)}`,
      flags: MessageFlags.Ephemeral
    });
  }

  army.coins -= totalCost;
  army.soldiers[type] -= actualQty;
  army.soldiers[training.to] = (army.soldiers[training.to] || 0) + actualQty;
  army.xp += actualQty * 2;
  
  const xpBoost = (army.boosters?.xp || 0) / 100;
  army.xp += Math.floor(actualQty * xpBoost);
  if (army.vip) army.xp += Math.floor(actualQty * 0.5);
  
  db.updateEconomy();
  db.addLog('train', { userId: interaction.user.id, type, to: training.to, quantity: actualQty, cost: totalCost });

  await interaction.reply({
    content: `✅ تم ترقية ${formatNumber(actualQty)} ${type} → ${training.to}!\n💰 التكلفة: ${formatNumber(totalCost)} عملة 💪`
  });
}

// ─── يومي ───
async function handleDaily(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const now = Date.now();
  const lastDaily = army.lastDaily || 0;
  const cooldown = 24 * 60 * 60 * 1000;

  if (now - lastDaily < cooldown) {
    const remaining = cooldown - (now - lastDaily);
    const hours = Math.floor(remaining / 3600000);
    const minutes = Math.floor((remaining % 3600000) / 60000);
    return interaction.reply({
      content: `⏳ المكافأة اليومية متاحة بعد ${hours} ساعة و ${minutes} دقيقة.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const streak = army.dailyStreak || 0;
  const bonus = streak * CONFIG.dailyStreakBonus;
  const baseReward = CONFIG.dailyCredits;
  const totalReward = baseReward + bonus;

  army.credits = (army.credits || 0) + totalReward;
  army.lastDaily = now;
  army.dailyStreak = streak + 1;
  // مكافأة Vegon اليومية
  army.vegon = (army.vegon || 0) + CONFIG.vegonDailyBonus;

  if (streak >= 7) {
    army.coins += 5000;
  }
  if (streak >= 30) {
    army.gold = (army.gold || 0) + 10;
  }

  db.updateEconomy();
  db.addLog('daily', { userId: interaction.user.id, reward: totalReward, streak: army.dailyStreak });

  const embed = new EmbedBuilder()
    .setColor(0x2ECC71)
    .setTitle('🎁 المكافأة اليومية!')
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '💳 الكريدت', value: `**+${formatNumber(totalReward)}**`, inline: true },
      { name: '🔥 السلسلة', value: `**${army.dailyStreak} يوم**`, inline: true },
      { name: '✨ المكافأة الإضافية', value: `**+${bonus}**`, inline: true },
      { name: '💎 Vegon', value: `**+${CONFIG.vegonDailyBonus} VGN**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── العمل ───
async function handleWork(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const now = Date.now();
  const cooldown = 30 * 60 * 1000;

  if (now - (army.lastWork || 0) < cooldown) {
    const remaining = cooldown - (now - army.lastWork);
    const minutes = Math.floor(remaining / 60000);
    return interaction.reply({
      content: `⏳ استنى ${minutes} دقيقة قبل العمل تاني.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const baseEarn = randomInt(100, 500);
  const bonus = army.buildings.قاعدة ? randomInt(50, 200) : 0;
  const total = baseEarn + bonus;

  const coinBoost = (army.boosters?.coin || 0) / 100;
  let finalEarn = Math.floor(total * (1 + coinBoost));
  if (army.vip) finalEarn = Math.floor(finalEarn * 1.5);

  army.coins += finalEarn;
  army.lastWork = now;
  db.updateEconomy();
  db.addLog('work', { userId: interaction.user.id, earned: finalEarn });

  const embed = new EmbedBuilder()
    .setColor(0x3498DB)
    .setTitle('💼 عملت وكسبت!')
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '💰 المكسب', value: `**+${formatNumber(finalEarn)} عملة**`, inline: true },
      { name: '🏗️ مكافأة القاعدة', value: `**+${bonus}**`, inline: true },
      { name: '💼 رصيدك', value: `**${formatNumber(army.coins)}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── المبارزة ───
async function handleDuel(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const opponent = interaction.options.getUser('الخصم');
  const bet = interaction.options.getInteger('الرهان') || 0;

  if (opponent.id === interaction.user.id) {
    return interaction.reply({
      content: '❌ مينفعش تتحدى نفسك!',
      flags: MessageFlags.Ephemeral
    });
  }

  const oppArmy = db.getArmy(opponent.id);
  if (!oppArmy) {
    return interaction.reply({
      content: `❌ ${opponent.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (bet > 0 && army.coins < bet) {
    return interaction.reply({
      content: `❌ مش عندك عملات كافية للرهان. عندك ${formatNumber(army.coins)}`,
      flags: MessageFlags.Ephemeral
    });
  }

  const duelId = genConfirmCode();
  db.data.duels[duelId] = {
    challenger: interaction.user.id,
    opponent: opponent.id,
    bet: bet,
    status: 'pending',
    createdAt: Date.now()
  };
  db.save();

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle('⚔️ طلب مبارزة')
    .setDescription(`${interaction.user.username} يتحدى ${opponent.username}!`)
    .addFields(
      { name: '💰 الرهان', value: bet > 0 ? `**${formatNumber(bet)} عملة**` : '**بدون رهان**', inline: true },
      { name: '⚡ قوة المتحدي', value: `**${formatNumber(calcPower(army))}**`, inline: true },
      { name: '⚡ قوة الخصم', value: `**${formatNumber(calcPower(oppArmy))}**`, inline: true }
    )
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`duel_accept_${duelId}`)
      .setLabel('✅ قبول')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`duel_reject_${duelId}`)
      .setLabel('❌ رفض')
      .setStyle(ButtonStyle.Danger)
  );

  const msg = await interaction.reply({ content: `<@${opponent.id}>`, embeds: [embed], components: [row] });

  const filter = i => i.user.id === opponent.id;
  const collector = msg.createMessageComponentCollector({ filter, time: 60000, max: 1 });

  collector.on('collect', async (i) => {
    const duel = db.data.duels[duelId];
    if (!duel || duel.status !== 'pending') {
      return i.reply({
        content: '❌ المبارزة انتهت.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (i.customId === `duel_reject_${duelId}`) {
      duel.status = 'rejected';
      db.save();
      return i.update({
        content: `❌ ${opponent.username} رفض المبارزة.`,
        components: []
      });
    }

    duel.status = 'accepted';
    db.save();

    const power1 = calcPower(army);
    const power2 = calcPower(oppArmy);
    const power1Boosted = power1 * (1 + (army.boosters?.attack || 0) / 100);
    const power2Boosted = power2 * (1 + (oppArmy.boosters?.attack || 0) / 100);

    const roll1 = power1Boosted * (0.7 + Math.random() * 0.6);
    const roll2 = power2Boosted * (0.7 + Math.random() * 0.6);

    let winner, loser, winnerArmy, loserArmy;
    if (roll1 > roll2) {
      winner = interaction.user;
      loser = opponent;
      winnerArmy = army;
      loserArmy = oppArmy;
      army.duelStats.wins++;
      oppArmy.duelStats.losses++;
    } else if (roll2 > roll1) {
      winner = opponent;
      loser = interaction.user;
      winnerArmy = oppArmy;
      loserArmy = army;
      oppArmy.duelStats.wins++;
      army.duelStats.losses++;
    } else {
      duel.status = 'draw';
      db.save();
      army.duelStats.draws = (army.duelStats.draws || 0) + 1;
      oppArmy.duelStats.draws = (oppArmy.duelStats.draws || 0) + 1;
      return i.update({
        content: `⚖️ تعادل! ${interaction.user.username} و ${opponent.username} متعادلين.`,
        components: []
      });
    }

    if (bet > 0) {
      winnerArmy.coins += bet;
      loserArmy.coins -= bet;
    }

    db.updateEconomy();
    db.addLog('duel', {
      challenger: interaction.user.id,
      opponent: opponent.id,
      winner: winner.id,
      bet,
      power1: power1Boosted,
      power2: power2Boosted
    });

    const resultEmbed = new EmbedBuilder()
      .setColor(winner.id === interaction.user.id ? 0x2ECC71 : 0xE74C3C)
      .setTitle(`⚔️ نتيجة المبارزة`)
      .setDescription(`**${winner.username}** انتصر على **${loser.username}**! 🎉`)
      .addFields(
        { name: '🏆 الفائز', value: `<@${winner.id}>`, inline: true },
        { name: '💰 الرهان', value: bet > 0 ? `**${formatNumber(bet)} عملة**` : 'بدون', inline: true },
        { name: '📊 قوة الفائز', value: `**${formatNumber(Math.max(roll1, roll2))}**`, inline: true },
        { name: '📊 قوة الخاسر', value: `**${formatNumber(Math.min(roll1, roll2))}**`, inline: true }
      )
      .setTimestamp();

    await i.update({ embeds: [resultEmbed], components: [] });
    duel.status = 'completed';
    db.save();
  });

  collector.on('end', (collected) => {
    if (collected.size === 0) {
      const duel = db.data.duels[duelId];
      if (duel && duel.status === 'pending') {
        duel.status = 'expired';
        db.save();
        msg.edit({
          content: `⏳ انتهى وقت المبارزة.`,
          components: []
        });
      }
    }
  });
}

// ─── التحالف ───
async function handleAlliance(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (army.alliance) {
    return interaction.reply({
      content: `❌ أنت بالفعل في تحالف ${army.alliance}.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const name = interaction.options.getString('الاسم');
  
  if (db.data.alliances[name]) {
    return interaction.reply({
      content: `❌ تحالف ${name} موجود بالفعل.`,
      flags: MessageFlags.Ephemeral
    });
  }

  db.data.alliances[name] = {
    name: name,
    leader: interaction.user.id,
    members: [interaction.user.id],
    createdAt: Date.now(),
    wars: [],
    allies: [],
    description: 'تحالف جديد'
  };

  army.alliance = name;
  army.allianceRole = 'leader';
  db.save();
  db.addLog('alliance_create', { userId: interaction.user.id, name });

  const embed = new EmbedBuilder()
    .setColor(0x3498DB)
    .setTitle(`🤝 تم إنشاء تحالف ${name}!`)
    .setDescription(`أنت الآن قائد التحالف.\nاستخدم \`/انضمام [اسم]\` لدعوة الأعضاء.`)
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الانضمام ───
async function handleJoin(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (army.alliance) {
    return interaction.reply({
      content: `❌ أنت بالفعل في تحالف ${army.alliance}.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const name = interaction.options.getString('التحالف');
  const alliance = db.data.alliances[name];

  if (!alliance) {
    return interaction.reply({
      content: `❌ تحالف ${name} غير موجود.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (!db.data.joinRequests[name]) db.data.joinRequests[name] = [];
  db.data.joinRequests[name].push(interaction.user.id);
  db.save();

  try {
    const leader = await client.users.fetch(alliance.leader);
    await leader.send(`📩 طلب انضمام جديد من ${interaction.user.username} لتحالف ${name}`);
  } catch {}

  await interaction.reply({
    content: `✅ تم إرسال طلب انضمام لتحالف ${name}. انتظر موافقة القائد.`,
    flags: MessageFlags.Ephemeral
  });
}

// ─── الطلبات ───
async function handleRequests(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || (alliance.leader !== interaction.user.id && army.allianceRole !== 'admin')) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const requests = db.data.joinRequests[army.alliance] || [];
  if (!requests.length) {
    return interaction.reply({
      content: '📭 مفيش طلبات انضمام.',
      flags: MessageFlags.Ephemeral
    });
  }

  const embed = new EmbedBuilder()
    .setColor(0xF39C12)
    .setTitle(`📩 طلبات انضمام لتحالف ${army.alliance}`)
    .setDescription(requests.map(id => `<@${id}>`).join('\n'))
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── القبول ───
async function handleAccept(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || (alliance.leader !== interaction.user.id && army.allianceRole !== 'admin')) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('اللاعب');
  const requests = db.data.joinRequests[army.alliance] || [];

  if (!requests.includes(target.id)) {
    return interaction.reply({
      content: `❌ ${target.username} ليس لديه طلب انضمام.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const targetArmy = db.getArmy(target.id);
  if (targetArmy) {
    targetArmy.alliance = army.alliance;
    targetArmy.allianceRole = 'member';
    alliance.members.push(target.id);
    // مكافأة Vegon للانضمام للتحالف
    targetArmy.vegon = (targetArmy.vegon || 0) + CONFIG.vegonAllianceBonus;
  }

  db.data.joinRequests[army.alliance] = requests.filter(id => id !== target.id);
  db.save();
  db.addLog('alliance_accept', { userId: target.id, alliance: army.alliance });

  await interaction.reply({
    content: `✅ تم قبول ${target.username} في تحالف ${army.alliance}!`
  });

  try {
    await target.send(`🎉 تم قبولك في تحالف ${army.alliance}! حصلت على **+${CONFIG.vegonAllianceBonus} VGN** 💎`);
  } catch {}
}

// ─── الرفض ───
async function handleReject(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || (alliance.leader !== interaction.user.id && army.allianceRole !== 'admin')) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('اللاعب');
  const requests = db.data.joinRequests[army.alliance] || [];

  if (!requests.includes(target.id)) {
    return interaction.reply({
      content: `❌ ${target.username} ليس لديه طلب انضمام.`,
      flags: MessageFlags.Ephemeral
    });
  }

  db.data.joinRequests[army.alliance] = requests.filter(id => id !== target.id);
  db.save();

  await interaction.reply({
    content: `❌ تم رفض ${target.username} من تحالف ${army.alliance}.`
  });
}

// ─── الترقية ───
async function handlePromote(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || alliance.leader !== interaction.user.id) {
    return interaction.reply({
      content: '❌ فقط القائد يمكنه الترقية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('اللاعب');
  if (target.id === interaction.user.id) {
    return interaction.reply({
      content: '❌ لا يمكنك ترقية نفسك.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (!alliance.members.includes(target.id)) {
    return interaction.reply({
      content: `❌ ${target.username} ليس في تحالفك.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const targetArmy = db.getArmy(target.id);
  if (targetArmy) {
    targetArmy.allianceRole = 'admin';
    db.save();
    db.addLog('alliance_promote', { userId: target.id, alliance: army.alliance });
    await interaction.reply({
      content: `✅ تم ترقية ${target.username} لمشرف في تحالف ${army.alliance}!`
    });
  } else {
    await interaction.reply({
      content: `❌ ${target.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }
}

// ─── التخفيض ───
async function handleDemote(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || alliance.leader !== interaction.user.id) {
    return interaction.reply({
      content: '❌ فقط القائد يمكنه التخفيض.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('اللاعب');
  if (target.id === interaction.user.id) {
    return interaction.reply({
      content: '❌ لا يمكنك تخفيض نفسك.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (!alliance.members.includes(target.id)) {
    return interaction.reply({
      content: `❌ ${target.username} ليس في تحالفك.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const targetArmy = db.getArmy(target.id);
  if (targetArmy) {
    targetArmy.allianceRole = 'member';
    db.save();
    db.addLog('alliance_demote', { userId: target.id, alliance: army.alliance });
    await interaction.reply({
      content: `✅ تم تخفيض ${target.username} لعضو في تحالف ${army.alliance}.`
    });
  } else {
    await interaction.reply({
      content: `❌ ${target.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }
}

// ─── الطرد ───
async function handleKick(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || (alliance.leader !== interaction.user.id && army.allianceRole !== 'admin')) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية للطرد.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('اللاعب');
  if (target.id === interaction.user.id) {
    return interaction.reply({
      content: '❌ لا يمكنك طرد نفسك.',
      flags: MessageFlags.Ephemeral
    });
  }

  if (!alliance.members.includes(target.id)) {
    return interaction.reply({
      content: `❌ ${target.username} ليس في تحالفك.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const targetArmy = db.getArmy(target.id);
  if (targetArmy) {
    targetArmy.alliance = null;
    targetArmy.allianceRole = null;
  }

  alliance.members = alliance.members.filter(id => id !== target.id);
  db.save();
  db.addLog('alliance_kick', { userId: target.id, alliance: army.alliance });

  await interaction.reply({
    content: `❌ تم طرد ${target.username} من تحالف ${army.alliance}.`
  });
}

// ─── الخروج ───
async function handleLeave(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance) {
    army.alliance = null;
    army.allianceRole = null;
    db.save();
    return interaction.reply({
      content: '❌ التحالف غير موجود. تمت إزالة رابط التحالف.'
    });
  }

  if (alliance.leader === interaction.user.id) {
    return interaction.reply({
      content: '❌ أنت قائد التحالف. استخدم `/حذف_تحالف` لحذفه أو قم بترقية شخص آخر أولاً.',
      flags: MessageFlags.Ephemeral
    });
  }

  alliance.members = alliance.members.filter(id => id !== interaction.user.id);
  const allianceName = army.alliance;
  army.alliance = null;
  army.allianceRole = null;
  db.save();
  db.addLog('alliance_leave', { userId: interaction.user.id, alliance: allianceName });

  await interaction.reply({
    content: `✅ تم الخروج من تحالف ${allianceName}.`
  });
}

// ─── حذف التحالف ───
async function handleDeleteAlliance(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || alliance.leader !== interaction.user.id) {
    return interaction.reply({
      content: '❌ فقط القائد يمكنه حذف التحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  for (const memberId of alliance.members) {
    const memberArmy = db.getArmy(memberId);
    if (memberArmy) {
      memberArmy.alliance = null;
      memberArmy.allianceRole = null;
    }
  }

  const allianceName = army.alliance;
  delete db.data.alliances[army.alliance];
  delete db.data.joinRequests[army.alliance];
  db.save();
  db.addLog('alliance_delete', { userId: interaction.user.id, alliance: allianceName });

  await interaction.reply({
    content: `✅ تم حذف تحالف ${allianceName}.`
  });
}

// ─── الحرب ───
async function handleWar(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || alliance.leader !== interaction.user.id) {
    return interaction.reply({
      content: '❌ فقط القائد يمكنه إعلان الحرب.',
      flags: MessageFlags.Ephemeral
    });
  }

  const targetName = interaction.options.getString('التحالف');
  const targetAlliance = db.data.alliances[targetName];

  if (!targetAlliance || targetName === army.alliance) {
    return interaction.reply({
      content: `❌ تحالف غير صحيح.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const existingWar = db.data.wars.find(w => 
    (w.alliance1 === army.alliance && w.alliance2 === targetName) ||
    (w.alliance1 === targetName && w.alliance2 === army.alliance)
  );

  if (existingWar) {
    return interaction.reply({
      content: `⚔️ حرب بالفعل بين ${army.alliance} و ${targetName}!`,
      flags: MessageFlags.Ephemeral
    });
  }

  db.data.wars.push({
    alliance1: army.alliance,
    alliance2: targetName,
    startedAt: Date.now(),
    status: 'active',
    casualties: { alliance1: 0, alliance2: 0 },
    winner: null
  });
  db.save();

  const embed = new EmbedBuilder()
    .setColor(0xE74C3C)
    .setTitle('⚔️ إعلان حرب!')
    .setDescription(`**${army.alliance}** أعلن الحرب على **${targetName}**!`)
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── السلام ───
async function handlePeace(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || alliance.leader !== interaction.user.id) {
    return interaction.reply({
      content: '❌ فقط القائد يمكنه طلب السلام.',
      flags: MessageFlags.Ephemeral
    });
  }

  const targetName = interaction.options.getString('التحالف');
  const war = db.data.wars.find(w => 
    (w.alliance1 === army.alliance && w.alliance2 === targetName) ||
    (w.alliance1 === targetName && w.alliance2 === army.alliance)
  );

  if (!war) {
    return interaction.reply({
      content: `❌ لا توجد حرب بين ${army.alliance} و ${targetName}.`,
      flags: MessageFlags.Ephemeral
    });
  }

  war.peaceRequest = {
    from: army.alliance,
    to: targetName,
    requestedAt: Date.now()
  };
  db.save();

  const embed = new EmbedBuilder()
    .setColor(0x2ECC71)
    .setTitle('🕊️ طلب سلام')
    .setDescription(`**${army.alliance}** طلب السلام من **${targetName}**\nاستخدم \`/قبول_سلام ${targetName}\` لقبول الطلب.`)
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── قبول السلام ───
async function handleAcceptPeace(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance || alliance.leader !== interaction.user.id) {
    return interaction.reply({
      content: '❌ فقط القائد يمكنه قبول السلام.',
      flags: MessageFlags.Ephemeral
    });
  }

  const targetName = interaction.options.getString('التحالف');
  const war = db.data.wars.find(w => 
    (w.alliance1 === army.alliance && w.alliance2 === targetName) ||
    (w.alliance1 === targetName && w.alliance2 === army.alliance)
  );

  if (!war || !war.peaceRequest || war.peaceRequest.from !== targetName) {
    return interaction.reply({
      content: `❌ ${targetName} لم يطلب السلام.`,
      flags: MessageFlags.Ephemeral
    });
  }

  war.status = 'peace';
  war.peaceRequest.acceptedAt = Date.now();
  db.save();

  const embed = new EmbedBuilder()
    .setColor(0x2ECC71)
    .setTitle('🕊️ تم قبول السلام!')
    .setDescription(`**${army.alliance}** و **${targetName}** في سلام.`)
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── التحالفات ───
async function handleAlliances(interaction) {
  const alliances = Object.values(db.data.alliances);
  
  if (!alliances.length) {
    return interaction.reply({
      content: '📭 مفيش تحالفات للعرض.',
      flags: MessageFlags.Ephemeral
    });
  }

  const embed = new EmbedBuilder()
    .setColor(0x3498DB)
    .setTitle('🤝 قائمة التحالفات')
    .setDescription(alliances.map(a => {
      const members = a.members.length;
      const wars = db.data.wars.filter(w => 
        w.alliance1 === a.name || w.alliance2 === a.name
      ).filter(w => w.status === 'active').length;
      return `**${a.name}** — 👤 ${members} عضو${wars > 0 ? ` ⚔️ ${wars} حرب` : ''}`;
    }).join('\n'))
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الأعضاء ───
async function handleMembers(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army || !army.alliance) {
    return interaction.reply({
      content: '❌ أنت لست في تحالف.',
      flags: MessageFlags.Ephemeral
    });
  }

  const alliance = db.data.alliances[army.alliance];
  if (!alliance) {
    return interaction.reply({
      content: '❌ التحالف غير موجود.',
      flags: MessageFlags.Ephemeral
    });
  }

  const membersList = await Promise.all(alliance.members.map(async (id) => {
    const memberArmy = db.getArmy(id);
    const user = await client.users.fetch(id).catch(() => null);
    const username = user ? user.username : id;
    const role = id === alliance.leader ? '👑 قائد' : (memberArmy?.allianceRole === 'admin' ? '⭐ مشرف' : '👤 عضو');
    const power = memberArmy ? calcPower(memberArmy) : 0;
    return `${role} **${username}** — ⚡ ${formatNumber(power)}`;
  }));

  const embed = new EmbedBuilder()
    .setColor(0x3498DB)
    .setTitle(`👥 أعضاء تحالف ${army.alliance}`)
    .setDescription(membersList.join('\n') || 'مفيش أعضاء')
    .setFooter({ text: `إجمالي الأعضاء: ${alliance.members.length}` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── المساعدة ───
async function handleHelp(interaction) {
  const embed = new EmbedBuilder()
    .setColor(0x3498DB)
    .setTitle('📖 دليل لعبة الجيوش')
    .setDescription('**أوامر البوت الأساسية**')
    .addFields(
      { name: '🎮 الأساسيات', value: '`/بدء` — إنشاء جيش\n`/ملفي` — عرض معلوماتك\n`/توب` — أقوى الجيوش\n`/مساعدة` — هذه القائمة', inline: true },
      { name: '⚔️ القتال', value: '`/غارة` — غارة على الوحوش\n`/هجوم` — هجوم على لاعب\n`/مبارزة` — تحدي لاعب\n`/تجسس` — تجسس على لاعب', inline: true },
      { name: '🛒 المتجر', value: '`/متجر` — قائمة المشتريات\n`/تذكرة` — فتح تذكرة للشراء\n`/ذهب` — شراء ذهب\n`/كريدت` — عرض الرصيد\n`/تحويل` — تحويل العملات\n`/عروض` — العروض اليومية\n`/توصيات` — توصيات مخصصة', inline: true },
      { name: '💰 الموارد', value: '`/جمع` — جمع الدخل\n`/مخزون` — عرض المخزون\n`/عمل` — كسب عملات\n`/يومي` — مكافأة يومية\n`/شفاء` — شفاء الجنود', inline: true },
      { name: '🏗️ الدفاع', value: '`/جدار` — بناء جدار\n`/حماية` — تفعيل الدرع\n`/قاعدة` — ترقية القاعدة', inline: true },
      { name: '🤝 التحالفات', value: '`/تحالف` — إنشاء تحالف\n`/انضمام` — طلب انضمام\n`/طلبات` — عرض الطلبات\n`/قبول` — قبول عضو\n`/رفض` — رفض عضو', inline: true },
      { name: '👑 إدارة التحالف', value: '`/ترقية` — ترقية مشرف\n`/تخفيض` — تخفيض مشرف\n`/طرد` — طرد عضو\n`/خروج` — الخروج من التحالف\n`/حذف_تحالف` — حذف التحالف', inline: true },
      { name: '⚔️ الحروب', value: '`/حرب` — إعلان حرب\n`/سلام` — طلب سلام\n`/قبول_سلام` — قبول السلام', inline: true },
      { name: '📊 أخرى', value: '`/تحالفات` — قائمة التحالفات\n`/اعضاء` — أعضاء تحالفك\n`/اقتصاد` — حالة الاقتصاد\n`/اعطاء` — إعطاء لاعب\n`/كود` — كود خصم', inline: true }
    )
    .setFooter({ text: 'استخدم ! أو $ قبل الأمر للبريفكس' })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── المخزون ───
async function handleInventory(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const soldiers = Object.entries(army.soldiers)
    .filter(([, count]) => count > 0)
    .map(([type, count]) => `${type}: ${formatNumber(count)}`)
    .join('\n') || 'مفيش جنود';

  const missiles = Object.entries(army.missiles || {})
    .filter(([, count]) => count > 0)
    .map(([type, count]) => `${type}: ${formatNumber(count)}`)
    .join('\n') || 'مفيش صواريخ';

  const embed = new EmbedBuilder()
    .setColor(0xF39C12)
    .setTitle(`📦 مخزون ${army.name}`)
    .addFields(
      { name: '🪖 الجنود', value: soldiers, inline: true },
      { name: '🚀 الصواريخ', value: missiles, inline: true },
      { name: '⛏️ المناجم', value: `**${army.mines}**`, inline: true },
      { name: '🛢️ النفط', value: `**${army.oilRigs}**`, inline: true },
      { name: '🌾 المزارع', value: `**${army.farms || 0}**`, inline: true },
      { name: '🏭 المصانع', value: `**${army.factories || 0}**`, inline: true },
      { name: '🏥 صحة القاعدة', value: `**${army.baseHP || 0}/${army.baseMaxHP || 1000}**`, inline: true },
      { name: '🐾 الحيوانات', value: army.pets?.length ? army.pets.join(', ') : 'مفيش', inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الإعطاء ───
async function handleGive(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('اللاعب');
  const type = interaction.options.getString('نوع');
  const amount = interaction.options.getInteger('الكمية');

  if (target.id === interaction.user.id) {
    return interaction.reply({
      content: '❌ لا يمكنك إعطاء نفسك.',
      flags: MessageFlags.Ephemeral
    });
  }

  const targetArmy = db.getArmy(target.id);
  if (!targetArmy) {
    return interaction.reply({
      content: `❌ ${target.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  switch (type) {
    case 'coins': {
      if (army.coins < amount) {
        return interaction.reply({
          content: `❌ مش عندك عملات كافية. عندك ${formatNumber(army.coins)}`,
          flags: MessageFlags.Ephemeral
        });
      }
      army.coins -= amount;
      targetArmy.coins += amount;
      break;
    }
    case 'credits': {
      if ((army.credits || 0) < amount) {
        return interaction.reply({
          content: `❌ مش عندك كريدت كافي. عندك ${formatNumber(army.credits || 0)}`,
          flags: MessageFlags.Ephemeral
        });
      }
      army.credits -= amount;
      targetArmy.credits = (targetArmy.credits || 0) + amount;
      break;
    }
    case 'gold': {
      if ((army.gold || 0) < amount) {
        return interaction.reply({
          content: `❌ مش عندك ذهب كافي. عندك ${army.gold || 0}`,
          flags: MessageFlags.Ephemeral
        });
      }
      army.gold -= amount;
      targetArmy.gold = (targetArmy.gold || 0) + amount;
      break;
    }
    case 'soldiers': {
      const total = totalSoldiers(army);
      if (total < amount) {
        return interaction.reply({
          content: `❌ مش عندك جنود كافيين. عندك ${formatNumber(total)} جندي`,
          flags: MessageFlags.Ephemeral
        });
      }
      let rem = amount;
      for (const type2 of ['جندي', 'قناص', 'ضابط', 'عقيد', 'لواء', 'قوات_خاصة']) {
        if (rem <= 0) break;
        const take = Math.min(army.soldiers[type2] || 0, rem);
        army.soldiers[type2] -= take;
        targetArmy.soldiers[type2] = (targetArmy.soldiers[type2] || 0) + take;
        rem -= take;
      }
      break;
    }
    default: {
      return interaction.reply({
        content: '❌ نوع غير صحيح.',
        flags: MessageFlags.Ephemeral
      });
    }
  }

  db.updateEconomy();
  db.addLog('give', { userId: interaction.user.id, target: target.id, type, amount });

  await interaction.reply({
    content: `✅ تم إعطاء ${formatNumber(amount)} ${type} لـ ${target.username}`
  });
}

// ════════════════════════════════════════════════════════════════════
//  نظام عملة Vegon (VGN) - عملة السيرفر المرتبطة باللعبة
// ════════════════════════════════════════════════════════════════════

// ─── عرض رصيد Vegon ───
async function handleVegon(interaction) {
  const target = interaction.options.getUser('لاعب') || interaction.user;
  const army = db.getArmy(target.id);

  if (!army) {
    return interaction.reply({
      content: `❌ ${target.id === interaction.user.id ? 'مش عندك جيش.' : `${target.username} مش عنده جيش.`}`,
      flags: MessageFlags.Ephemeral
    });
  }

  const vegon = army.vegon || 0;
  const armies = Object.values(db.data.armies).sort((a, b) => (b.vegon || 0) - (a.vegon || 0));
  const rank = armies.findIndex(a => a.id === target.id) + 1;

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle('💎 محفظة Vegon')
    .setThumbnail(target.displayAvatarURL({ dynamic: true }))
    .setDescription(`**${army.name}**`)
    .addFields(
      { name: '💎 رصيد Vegon', value: `**${formatNumber(vegon)} VGN**`, inline: true },
      { name: '🏆 الترتيب', value: `**#${rank}**`, inline: true },
      { name: '📊 أسعار الصرف', value: `💰 ${formatNumber(CONFIG.coinsPerVegon)} عملة = 1 VGN\n💳 ${CONFIG.vegonPerCredit} كريدت = 1 VGN\n🥇 ${CONFIG.goldPerVegon} ذهب = 1 VGN`, inline: false },
      { name: '🎮 كيف تكسب Vegon؟', value: `⚔️ انتصار معركة: +${CONFIG.vegonVictoryReward} VGN\n🎁 يومي: +${CONFIG.vegonDailyBonus} VGN\n🎲 غارة: +${CONFIG.vegonRaidReward}+ VGN\n🔄 تحويل من عملات اللعبة`, inline: false }
    )
    .setFooter({ text: 'استخدم /تحويل_vegon لتحويل VGN لأعضاء آخرين' })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── تحويل Vegon بين الأعضاء ───
async function handleTransferVegon(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({ content: '❌ مش عندك جيش.', flags: MessageFlags.Ephemeral });
  }

  const target = interaction.options.getUser('اللاعب');
  const amount = interaction.options.getInteger('الكمية');

  if (target.id === interaction.user.id) {
    return interaction.reply({ content: '❌ لا تقدر تحول لنفسك.', flags: MessageFlags.Ephemeral });
  }

  if (target.bot) {
    return interaction.reply({ content: '❌ لا تقدر تحول للبوت.', flags: MessageFlags.Ephemeral });
  }

  const targetArmy = db.getArmy(target.id);
  if (!targetArmy) {
    return interaction.reply({ content: `❌ ${target.username} مش عنده جيش.`, flags: MessageFlags.Ephemeral });
  }

  // كولداون التحويل
  const now = Date.now();
  const lastTransfer = army.vegonLastTransfer || 0;
  if (now - lastTransfer < CONFIG.vegonTransferCooldownMs) {
    const remaining = Math.ceil((CONFIG.vegonTransferCooldownMs - (now - lastTransfer)) / 1000);
    return interaction.reply({
      content: `⏳ انتظر ${remaining} ثانية قبل التحويل التالي.`,
      flags: MessageFlags.Ephemeral
    });
  }

  const vegon = army.vegon || 0;
  if (vegon < amount) {
    return interaction.reply({
      content: `❌ رصيدك ${formatNumber(vegon)} VGN فقط. لا يكفي لتحويل ${formatNumber(amount)} VGN.`,
      flags: MessageFlags.Ephemeral
    });
  }

  // حساب الرسوم
  const fee = Math.ceil(amount * CONFIG.vegonTransferFee);
  const received = amount - fee;

  army.vegon = vegon - amount;
  targetArmy.vegon = (targetArmy.vegon || 0) + received;
  army.vegonLastTransfer = now;

  // سجل المعاملة
  if (!db.data.vegonTransactions) db.data.vegonTransactions = [];
  db.data.vegonTransactions.push({
    from: interaction.user.id,
    to: target.id,
    amount,
    fee,
    received,
    time: now
  });
  if (db.data.vegonTransactions.length > 500) db.data.vegonTransactions.splice(0, 100);

  db.save();
  db.addLog('vegon_transfer', { from: interaction.user.id, to: target.id, amount, fee });

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle('💎 تم التحويل بنجاح!')
    .addFields(
      { name: '📤 أرسلت', value: `**${formatNumber(amount)} VGN**`, inline: true },
      { name: '💸 الرسوم (2%)', value: `**${formatNumber(fee)} VGN**`, inline: true },
      { name: '📥 استلم', value: `**${formatNumber(received)} VGN**`, inline: true },
      { name: '👤 المستلم', value: `**${target.username}**`, inline: true },
      { name: '💼 رصيدك الآن', value: `**${formatNumber(army.vegon)} VGN**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  // إشعار للمستلم
  try {
    const targetUser = await interaction.client.users.fetch(target.id);
    await targetUser.send({
      embeds: [new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('💎 استلمت Vegon!')
        .setDescription(`**${interaction.user.username}** أرسل لك **${formatNumber(received)} VGN**`)
        .setTimestamp()
      ]
    }).catch(() => {});
  } catch {}
}

// ─── صرف Vegon ───
async function handleExchangeVegon(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({ content: '❌ مش عندك جيش.', flags: MessageFlags.Ephemeral });
  }

  const type = interaction.options.getString('نوع');
  const amount = interaction.options.getInteger('الكمية');

  let description = '';

  switch (type) {
    case 'vegon_to_coins': {
      const vegon = army.vegon || 0;
      if (vegon < amount) return interaction.reply({ content: `❌ رصيدك ${vegon} VGN فقط.`, flags: MessageFlags.Ephemeral });
      const coins = amount * CONFIG.coinsPerVegon;
      army.vegon = vegon - amount;
      army.coins += coins;
      description = `صرفت **${formatNumber(amount)} VGN** واستلمت **${formatNumber(coins)} عملة** 💰`;
      break;
    }
    case 'vegon_to_credits': {
      const vegon = army.vegon || 0;
      if (vegon < amount) return interaction.reply({ content: `❌ رصيدك ${vegon} VGN فقط.`, flags: MessageFlags.Ephemeral });
      const credits = amount * CONFIG.vegonPerCredit;
      army.vegon = vegon - amount;
      army.credits = (army.credits || 0) + credits;
      description = `صرفت **${formatNumber(amount)} VGN** واستلمت **${formatNumber(credits)} كريدت** 💳`;
      break;
    }
    case 'vegon_to_gold': {
      const vegon = army.vegon || 0;
      if (vegon < amount) return interaction.reply({ content: `❌ رصيدك ${vegon} VGN فقط.`, flags: MessageFlags.Ephemeral });
      const gold = Math.floor(amount / CONFIG.goldPerVegon);
      if (gold < 1) return interaction.reply({ content: `❌ الحد الأدنى ${CONFIG.goldPerVegon} VGN للحصول على 1 ذهب.`, flags: MessageFlags.Ephemeral });
      const actualVegon = gold * CONFIG.goldPerVegon;
      army.vegon = vegon - actualVegon;
      army.gold = (army.gold || 0) + gold;
      description = `صرفت **${formatNumber(actualVegon)} VGN** واستلمت **${gold} ذهب** 🥇`;
      break;
    }
    case 'coins_to_vegon': {
      const cost = amount * CONFIG.coinsPerVegon;
      if (army.coins < cost) return interaction.reply({ content: `❌ تحتاج ${formatNumber(cost)} عملة لشراء ${amount} VGN. عندك ${formatNumber(army.coins)}.`, flags: MessageFlags.Ephemeral });
      army.coins -= cost;
      army.vegon = (army.vegon || 0) + amount;
      description = `دفعت **${formatNumber(cost)} عملة** واستلمت **${formatNumber(amount)} VGN** 💎`;
      break;
    }
    case 'credits_to_vegon': {
      const cost = amount * CONFIG.vegonPerCredit;
      if ((army.credits || 0) < cost) return interaction.reply({ content: `❌ تحتاج ${formatNumber(cost)} كريدت. عندك ${formatNumber(army.credits || 0)}.`, flags: MessageFlags.Ephemeral });
      army.credits -= cost;
      army.vegon = (army.vegon || 0) + amount;
      description = `دفعت **${formatNumber(cost)} كريدت** واستلمت **${formatNumber(amount)} VGN** 💎`;
      break;
    }
    case 'gold_to_vegon': {
      const vegonReceived = Math.floor(amount / CONFIG.goldPerVegon);
      if (vegonReceived < 1) return interaction.reply({ content: `❌ الحد الأدنى ${CONFIG.goldPerVegon} ذهب = 1 VGN.`, flags: MessageFlags.Ephemeral });
      const actualGold = vegonReceived * CONFIG.goldPerVegon;
      if ((army.gold || 0) < actualGold) return interaction.reply({ content: `❌ تحتاج ${actualGold} ذهب. عندك ${army.gold || 0}.`, flags: MessageFlags.Ephemeral });
      army.gold -= actualGold;
      army.vegon = (army.vegon || 0) + vegonReceived;
      description = `دفعت **${actualGold} ذهب** واستلمت **${formatNumber(vegonReceived)} VGN** 💎`;
      break;
    }
    default:
      return interaction.reply({ content: '❌ نوع غير صحيح.', flags: MessageFlags.Ephemeral });
  }

  db.updateEconomy();
  db.save();
  db.addLog('vegon_exchange', { userId: interaction.user.id, type, amount });

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle('💎 تم الصرف!')
    .setDescription(description)
    .addFields(
      { name: '💎 رصيد Vegon الآن', value: `**${formatNumber(army.vegon || 0)} VGN**`, inline: true },
      { name: '💰 العملات الآن', value: `**${formatNumber(army.coins)}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── توب Vegon ───
async function handleTopVegon(interaction) {
  const armies = Object.values(db.data.armies)
    .sort((a, b) => (b.vegon || 0) - (a.vegon || 0))
    .slice(0, 10);

  if (!armies.length) {
    return interaction.reply({ content: '❌ مفيش لاعبين بعد.', flags: MessageFlags.Ephemeral });
  }

  const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
  const list = armies.map((a, i) => `${medals[i]} **${a.name}** — ${formatNumber(a.vegon || 0)} VGN`).join('\n');

  const totalVegon = Object.values(db.data.armies).reduce((sum, a) => sum + (a.vegon || 0), 0);

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle('💎 قائمة أثرياء Vegon')
    .setDescription(list)
    .addFields({ name: '🌐 إجمالي VGN في الاقتصاد', value: `**${formatNumber(totalVegon)} VGN**`, inline: false })
    .setFooter({ text: 'Vegon (VGN) — عملة السيرفر الرسمية' })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── إضافة Vegon (ادمن) ───
async function handleAddVegon(interaction) {
  if (!CONFIG.owners.includes(interaction.user.id) &&
      !interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
    return interaction.reply({ content: '❌ صلاحيات الادمن مطلوبة.', flags: MessageFlags.Ephemeral });
  }

  const target = interaction.options.getUser('لاعب');
  const amount = interaction.options.getInteger('الكمية');
  const targetArmy = db.getArmy(target.id);

  if (!targetArmy) {
    return interaction.reply({ content: `❌ ${target.username} مش عنده جيش.`, flags: MessageFlags.Ephemeral });
  }

  targetArmy.vegon = (targetArmy.vegon || 0) + amount;
  db.save();
  db.addLog('admin_add_vegon', { admin: interaction.user.id, target: target.id, amount });

  await interaction.reply({
    content: `✅ تم إضافة **${formatNumber(amount)} VGN** لـ **${target.username}** | رصيده الآن: **${formatNumber(targetArmy.vegon)} VGN**`
  });
}

// ─── خصم Vegon (ادمن) ───
async function handleRemoveVegon(interaction) {
  if (!CONFIG.owners.includes(interaction.user.id) &&
      !interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
    return interaction.reply({ content: '❌ صلاحيات الادمن مطلوبة.', flags: MessageFlags.Ephemeral });
  }

  const target = interaction.options.getUser('لاعب');
  const amount = interaction.options.getInteger('الكمية');
  const reason = interaction.options.getString('سبب') || 'لا يوجد سبب';
  const targetArmy = db.getArmy(target.id);

  if (!targetArmy) {
    return interaction.reply({ content: `❌ ${target.username} مش عنده جيش.`, flags: MessageFlags.Ephemeral });
  }

  if ((targetArmy.vegon || 0) < amount) {
    return interaction.reply({ content: `❌ رصيد ${target.username} هو **${formatNumber(targetArmy.vegon || 0)} VGN** فقط.`, flags: MessageFlags.Ephemeral });
  }

  targetArmy.vegon = (targetArmy.vegon || 0) - amount;
  db.save();
  db.addLog('admin_remove_vegon', { admin: interaction.user.id, target: target.id, amount, reason });

  await interaction.reply({
    content: `✅ تم خصم **${formatNumber(amount)} VGN** من **${target.username}** | السبب: ${reason} | رصيده الآن: **${formatNumber(targetArmy.vegon)} VGN**`
  });

  // إشعار اللاعب
  try {
    const targetUser = await interaction.client.users.fetch(target.id);
    await targetUser.send({
      embeds: [new EmbedBuilder()
        .setColor(0xE74C3C)
        .setTitle('⚠️ خصم Vegon')
        .setDescription(`تم خصم **${formatNumber(amount)} VGN** من رصيدك.\n📋 السبب: ${reason}\n💎 رصيدك الآن: **${formatNumber(targetArmy.vegon)} VGN**`)
        .setTimestamp()
      ]
    }).catch(() => {});
  } catch {}
}

// ─── سجل معاملات Vegon ───
async function handleVegonLog(interaction) {
  const target = interaction.options.getUser('لاعب') || interaction.user;
  const army = db.getArmy(target.id);

  if (!army) {
    return interaction.reply({ content: `❌ ${target.id === interaction.user.id ? 'مش عندك جيش.' : `${target.username} مش عنده جيش.`}`, flags: MessageFlags.Ephemeral });
  }

  const transactions = (db.data.vegonTransactions || [])
    .filter(t => t.from === target.id || t.to === target.id)
    .slice(-15)
    .reverse();

  if (!transactions.length) {
    return interaction.reply({ content: '📭 لا توجد معاملات Vegon بعد.', flags: MessageFlags.Ephemeral });
  }

  const lines = await Promise.all(transactions.map(async t => {
    const date = new Date(t.time).toLocaleDateString('ar-EG');
    const isSender = t.from === target.id;
    try {
      const otherUser = await interaction.client.users.fetch(isSender ? t.to : t.from).catch(() => null);
      const otherName = otherUser ? otherUser.username : 'مجهول';
      if (isSender) {
        return `📤 أرسلت **${formatNumber(t.amount)} VGN** لـ ${otherName} _(رسوم: ${t.fee})_ — ${date}`;
      } else {
        return `📥 استلمت **${formatNumber(t.received)} VGN** من ${otherName} — ${date}`;
      }
    } catch {
      return `🔄 معاملة ${formatNumber(t.amount)} VGN — ${date}`;
    }
  }));

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle(`💎 سجل معاملات Vegon — ${target.username}`)
    .setDescription(lines.join('\n'))
    .addFields({ name: '💎 الرصيد الحالي', value: `**${formatNumber(army.vegon || 0)} VGN**`, inline: true })
    .setFooter({ text: 'آخر 15 معاملة' })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── معلومات نظام Vegon ───
async function handleVegonInfo(interaction) {
  const armies = Object.values(db.data.armies);
  const totalVegon = armies.reduce((sum, a) => sum + (a.vegon || 0), 0);
  const richest = armies.sort((a, b) => (b.vegon || 0) - (a.vegon || 0))[0];
  const transactions = db.data.vegonTransactions || [];
  const totalTransferred = transactions.reduce((sum, t) => sum + t.amount, 0);

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle('💎 نظام عملة Vegon (VGN)')
    .setDescription('عملة السيرفر الرسمية المرتبطة بلعبة الجيوش')
    .addFields(
      { name: '🌐 إجمالي VGN في الاقتصاد', value: `**${formatNumber(totalVegon)} VGN**`, inline: true },
      { name: '👥 عدد اللاعبين', value: `**${armies.length}**`, inline: true },
      { name: '🔄 إجمالي التحويلات', value: `**${formatNumber(totalTransferred)} VGN**`, inline: true },
      { name: '👑 أغنى لاعب', value: richest ? `**${richest.name}** — ${formatNumber(richest.vegon || 0)} VGN` : 'لا يوجد', inline: true },
      { name: '\u200B', value: '\u200B', inline: true },
      { name: '\u200B', value: '\u200B', inline: true },
      { name: '📊 أسعار الصرف', value: `💰 ${formatNumber(CONFIG.coinsPerVegon)} عملة = 1 VGN\n💳 ${CONFIG.vegonPerCredit} كريدت = 1 VGN\n🥇 ${CONFIG.goldPerVegon} ذهب = 1 VGN`, inline: false },
      { name: '🎮 طرق الكسب', value: `⚔️ انتصار معركة: **+${CONFIG.vegonVictoryReward} VGN**\n🎁 مكافأة يومية: **+${CONFIG.vegonDailyBonus} VGN**\n🎲 غارة: **+${CONFIG.vegonRaidReward}+ VGN**\n🤝 تحالف: **+${CONFIG.vegonAllianceBonus} VGN**`, inline: false },
      { name: '⚙️ إعدادات التحويل', value: `💸 رسوم التحويل: **${CONFIG.vegonTransferFee * 100}%**\n⏳ كولداون: **${CONFIG.vegonTransferCooldownMs / 1000} ثانية**\n🎁 رصيد البداية: **${CONFIG.startingVegon} VGN**`, inline: false },
      { name: '📋 الأوامر المتاحة', value: '`/vegon` — رصيدك\n`/تحويل_vegon` — تحويل لعضو\n`/صرف_vegon` — صرف العملة\n`/توب_vegon` — قائمة الأثرياء\n`/سجل_vegon` — سجل معاملاتك', inline: false }
    )
    .setFooter({ text: 'Vegon (VGN) — عملة السيرفر الرسمية' })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الاقتصاد ───
async function handleEconomy(interaction) {
  const armies = Object.values(db.data.armies);
  const totalCoins = armies.reduce((sum, a) => sum + (a.coins || 0), 0);
  const totalCredits = armies.reduce((sum, a) => sum + (a.credits || 0), 0);
  const totalGold = armies.reduce((sum, a) => sum + (a.gold || 0), 0);
  const totalSoldiersCount = armies.reduce((sum, a) => sum + totalSoldiers(a), 0);
  const totalPower = armies.reduce((sum, a) => sum + calcPower(a), 0);

  const embed = new EmbedBuilder()
    .setColor(0xF39C12)
    .setTitle('📊 حالة الاقتصاد')
    .addFields(
      { name: '💰 إجمالي العملات', value: `**${formatNumber(totalCoins)}**`, inline: true },
      { name: '💳 إجمالي الكريدت', value: `**${formatNumber(totalCredits)}**`, inline: true },
      { name: '🏆 إجمالي الذهب', value: `**${formatNumber(totalGold)}**`, inline: true },
      { name: '🪖 إجمالي الجنود', value: `**${formatNumber(totalSoldiersCount)}**`, inline: true },
      { name: '⚡ إجمالي القوة', value: `**${formatNumber(totalPower)}**`, inline: true },
      { name: '👥 عدد اللاعبين', value: `**${armies.length}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الشفاء ───
async function handleHeal(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const medics = army.soldiers.طبيب || 0;
  if (medics === 0) {
    return interaction.reply({
      content: '❌ مش عندك أطباء! اشترِ من `/متجر`',
      flags: MessageFlags.Ephemeral
    });
  }

  const now = Date.now();
  const cooldown = 3600000;
  if (now - (army.lastHeal || 0) < cooldown) {
    const remaining = cooldown - (now - (army.lastHeal || 0));
    const minutes = Math.floor(remaining / 60000);
    return interaction.reply({
      content: `⏳ استنى ${minutes} دقيقة قبل الشفاء تاني.`,
      flags: MessageFlags.Ephemeral
    });
  }

  let healed = 0;
  for (const type of ['جندي', 'قناص', 'ضابط', 'عقيد', 'لواء', 'قوات_خاصة']) {
    if (army.soldiers[type] > 0) {
      const healAmount = Math.min(army.soldiers[type] * 0.1, medics * 2);
      army.soldiers[type] += Math.floor(healAmount);
      healed += Math.floor(healAmount);
    }
  }

  const healBase = Math.min(medics * 10, (army.baseMaxHP || 1000) - (army.baseHP || 0));
  army.baseHP = (army.baseHP || 0) + healBase;

  army.lastHeal = now;
  db.save();
  db.addLog('heal', { userId: interaction.user.id, healed, healBase });

  const embed = new EmbedBuilder()
    .setColor(0x2ECC71)
    .setTitle('🏥 تم الشفاء!')
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '💉 الجنود المشفيين', value: `**+${healed}**`, inline: true },
      { name: '🏥 صحة القاعدة', value: `**+${healBase}**`, inline: true },
      { name: '🏥 صحة القاعدة الآن', value: `**${army.baseHP}/${army.baseMaxHP || 1000}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الجدار ───
async function handleWall(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const quantity = interaction.options.getInteger('الكمية');
  const costPerWall = 2000;
  const totalCost = costPerWall * quantity;

  if (army.coins < totalCost) {
    return interaction.reply({
      content: `❌ محتاج ${formatNumber(totalCost)} عملة. عندك ${formatNumber(army.coins)}`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (!army.defenseBuildings) army.defenseBuildings = {};
  army.defenseBuildings.walls = (army.defenseBuildings.walls || 0) + quantity;
  army.coins -= totalCost;
  
  db.updateEconomy();
  db.addLog('wall_build', { userId: interaction.user.id, quantity, cost: totalCost });

  const embed = new EmbedBuilder()
    .setColor(0xF39C12)
    .setTitle('🧱 تم بناء الجدران!')
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '🧱 الجدران', value: `**+${quantity}**`, inline: true },
      { name: '💰 التكلفة', value: `**${formatNumber(totalCost)} عملة**`, inline: true },
      { name: '🛡️ الدفاع الإجمالي', value: `**${formatNumber(calcDefense(army))}**`, inline: true },
      { name: '🧱 إجمالي الجدران', value: `**${army.defenseBuildings.walls}**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── التجسس ───
async function handleSpy(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('الهدف');
  const targetArmy = db.getArmy(target.id);

  if (!targetArmy) {
    return interaction.reply({
      content: `❌ ${target.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (target.id === interaction.user.id) {
    return interaction.reply({
      content: '❌ مينفعش تتجسس على نفسك!',
      flags: MessageFlags.Ephemeral
    });
  }

  const cost = 10000;
  if (army.coins < cost) {
    return interaction.reply({
      content: `❌ محتاج ${formatNumber(cost)} عملة للتجسس.`,
      flags: MessageFlags.Ephemeral
    });
  }

  army.coins -= cost;
  const spies = army.spies || 0;
  const successRate = Math.min(0.8 + spies * 0.02, 0.95);
  const success = Math.random() < successRate;

  db.updateEconomy();

  if (!success) {
    const embed = new EmbedBuilder()
      .setColor(0xE74C3C)
      .setTitle('🕵️ فشل التجسس!')
      .setDescription(`فشل التجسس على ${target.username}. ضاع ${formatNumber(cost)} عملة.`)
      .setTimestamp();
    return interaction.reply({ embeds: [embed] });
  }

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle(`🕵️ معلومات عن ${target.username}`)
    .setThumbnail(target.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '⚡ القوة', value: `**${formatNumber(calcPower(targetArmy))}**`, inline: true },
      { name: '🛡️ الدفاع', value: `**${formatNumber(calcDefense(targetArmy))}**`, inline: true },
      { name: '💰 العملات', value: `**${formatNumber(targetArmy.coins)}**`, inline: true },
      { name: '🏆 الذهب', value: `**${targetArmy.gold || 0}**`, inline: true },
      { name: '🪖 إجمالي الجنود', value: `**${formatNumber(totalSoldiers(targetArmy))}**`, inline: true },
      { name: '🏗️ المباني', value: Object.entries(targetArmy.buildings).filter(([, v]) => v).map(([b]) => b).join(', ') || 'مفيش', inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── الحماية ───
async function handleProtection(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const shieldCost = 50000;
  if (army.coins < shieldCost) {
    return interaction.reply({
      content: `❌ محتاج ${formatNumber(shieldCost)} عملة للدرع.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (isProtected(army)) {
    return interaction.reply({
      content: '🛡️ أنت محمي بالفعل!',
      flags: MessageFlags.Ephemeral
    });
  }

  army.coins -= shieldCost;
  army.protected = true;
  army.protectedUntil = Date.now() + CONFIG.protectionDuration * 2;

  db.updateEconomy();
  db.addLog('protection', { userId: interaction.user.id });

  const embed = new EmbedBuilder()
    .setColor(0x2ECC71)
    .setTitle('🛡️ تم تفعيل الحماية!')
    .setDescription(`أنت محمي حتى <t:${Math.floor(army.protectedUntil / 1000)}:R>`)
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── القاعدة ───
async function handleBase(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const upgradeCost = 100000 * (army.baseMaxHP || 1000) / 1000;
  if (army.coins < upgradeCost) {
    return interaction.reply({
      content: `❌ محتاج ${formatNumber(upgradeCost)} عملة لترقية القاعدة.`,
      flags: MessageFlags.Ephemeral
    });
  }

  army.coins -= upgradeCost;
  army.baseMaxHP = (army.baseMaxHP || 1000) + 500;
  army.baseHP = army.baseMaxHP;

  db.updateEconomy();
  db.addLog('base_upgrade', { userId: interaction.user.id, cost: upgradeCost });

  const embed = new EmbedBuilder()
    .setColor(0x2ECC71)
    .setTitle('🏢 تم ترقية القاعدة!')
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '🏥 صحة القاعدة', value: `**${army.baseHP}/${army.baseMaxHP}**`, inline: true },
      { name: '💰 التكلفة', value: `**${formatNumber(upgradeCost)} عملة**`, inline: true }
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

// ─── العروض ───
async function handleOffers(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const items = Object.values(db.data.shop.items);
  const shuffled = shuffleArray([...items]);
  const dailyOffers = shuffled.slice(0, 8).map(item => ({
    ...item,
    discount: randomInt(10, 40)
  }));

  const embed = new EmbedBuilder()
    .setColor(0xFF6B35)
    .setTitle('🔥 العروض اليومية')
    .setDescription('خصومات تصل إلى 40% على منتجات مختارة!')
    .setThumbnail(client.user.displayAvatarURL());

  let description = '';
  for (const offer of dailyOffers) {
    const originalPrice = offer.price || 0;
    const discountedPrice = Math.floor(originalPrice * (1 - offer.discount / 100));
    description += `\n${offer.emoji} **${offer.name}**\n`;
    description += `└ 💰 ~~${formatNumber(originalPrice)}~~ → **${formatNumber(discountedPrice)}** عملة (خصم ${offer.discount}%)\n`;
    description += `└ 📝 ${offer.desc}\n`;
  }

  embed.setDescription(description);
  embed.setFooter({ text: 'العروض تتجدد يومياً | استخدم /متجر للشراء' });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('offers_shop')
      .setLabel('🛒 الذهاب للمتجر')
      .setStyle(ButtonStyle.Success)
  );

  const msg = await interaction.reply({ embeds: [embed], components: [row] });

  const filter = i => i.user.id === interaction.user.id && i.customId === 'offers_shop';
  const collector = msg.createMessageComponentCollector({ filter, time: 30000, max: 1 });

  collector.on('collect', async (i) => {
    await handleShop(i);
  });
}

// ─── الكود ───
async function handleCode(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const code = interaction.options.getString('الكود');

  const discountData = db.data.discountCodes?.[code];
  if (!discountData || discountData.used || Date.now() > discountData.expiresAt) {
    return interaction.reply({
      content: '❌ كود غير صحيح أو منتهي الصلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  db.data.tempDiscount = {
    userId: interaction.user.id,
    code,
    discount: discountData.discount,
    expiresAt: Date.now() + 300000
  };
  discountData.used = true;
  discountData.usedBy = interaction.user.id;
  db.save();

  await interaction.reply({
    content: `✅ تم تطبيق خصم ${discountData.discount}%! استخدم \`/متجر\` للشراء بالخصم.`,
    flags: MessageFlags.Ephemeral
  });
}

// ─── التوصيات ───
async function handleRecommendations(interaction) {
  const army = db.getArmy(interaction.user.id);
  if (!army) {
    return interaction.reply({
      content: '❌ مش عندك جيش.',
      flags: MessageFlags.Ephemeral
    });
  }

  const items = db.data.shop.items;
  const recommended = [];
  const total = totalSoldiers(army);
  
  if (total < 100) recommended.push(items.soldier);
  if (!army.buildings.قاعدة) recommended.push(items.base);
  if (army.mines === 0) recommended.push(items.mine);
  if (army.buildings.قاعدة && !army.buildings.معسكر_تدريب) recommended.push(items.training);
  if (army.buildings.قاعدة && !army.buildings.أسوار) recommended.push(items.walls);
  if (army.victories > 10 && army.soldiers.قوات_خاصة < 10) recommended.push(items.elite);
  
  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle('💡 توصيات لجيشك')
    .setDescription('بناءً على احتياجات جيشك، ننصحك بهذه العناصر')
    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }));

  let description = '';
  for (const item of recommended) {
    if (!item) continue;
    description += `\n${item.emoji} **${item.name}**\n`;
    description += `└ 💰 ${formatNumber(item.price || 0)} عملة\n`;
    description += `└ 📝 ${item.desc}\n`;
  }

  embed.setDescription(description || '🎉 جيشك متكامل! استمر في التطوير.');
  embed.setFooter({ text: 'استخدم /متجر للشراء' });

  await interaction.reply({ embeds: [embed] });
}

// ─── أوامر المشرفين ───
async function handleAddCoins(interaction) {
  if (!isAdmin(interaction.user.id)) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('لاعب');
  const amount = interaction.options.getInteger('الكمية');

  const army = db.getArmy(target.id);
  if (!army) {
    return interaction.reply({
      content: `❌ ${target.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  army.coins += amount;
  db.updateEconomy();
  db.addLog('admin_add_coins', { admin: interaction.user.id, target: target.id, amount });

  await interaction.reply({
    content: `✅ تم إضافة ${formatNumber(amount)} عملة لـ ${target.username}`,
    flags: MessageFlags.Ephemeral
  });
}

async function handleAddCredits(interaction) {
  if (!isAdmin(interaction.user.id)) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('لاعب');
  const amount = interaction.options.getInteger('الكمية');

  const army = db.getArmy(target.id);
  if (!army) {
    return interaction.reply({
      content: `❌ ${target.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  army.credits = (army.credits || 0) + amount;
  db.updateEconomy();
  db.addLog('admin_add_credits', { admin: interaction.user.id, target: target.id, amount });

  await interaction.reply({
    content: `✅ تم إضافة ${formatNumber(amount)} كريدت لـ ${target.username}`,
    flags: MessageFlags.Ephemeral
  });
}

async function handleAddGold(interaction) {
  if (!isAdmin(interaction.user.id)) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('لاعب');
  const amount = interaction.options.getInteger('الكمية');

  const army = db.getArmy(target.id);
  if (!army) {
    return interaction.reply({
      content: `❌ ${target.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  army.gold = (army.gold || 0) + amount;
  db.updateEconomy();
  db.addLog('admin_add_gold', { admin: interaction.user.id, target: target.id, amount });

  await interaction.reply({
    content: `✅ تم إضافة ${formatNumber(amount)} ذهب لـ ${target.username}`,
    flags: MessageFlags.Ephemeral
  });
}

async function handleConfirmPay(interaction) {
  if (!isAdmin(interaction.user.id)) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const code = interaction.options.getString('الكود');
  const payment = db.data.pendingPayments[code];

  if (!payment) {
    return interaction.reply({
      content: '❌ الكود غير صحيح أو منتهي.',
      flags: MessageFlags.Ephemeral
    });
  }

  const army = db.getArmy(payment.userId);
  if (!army) {
    return interaction.reply({
      content: `❌ اللاعب مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  army.gold = (army.gold || 0) + payment.amount;
  army.credits = (army.credits || 0) + payment.amount * CONFIG.creditToGoldRate;

  delete db.data.pendingPayments[code];
  db.updateEconomy();
  db.addLog('payment_confirmed', { admin: interaction.user.id, userId: payment.userId, amount: payment.amount, code });

  try {
    const user = await client.users.fetch(payment.userId);
    await user.send(`🎉 تم تأكيد طلب شرائك!\n🏆 تمت إضافة ${payment.amount} ذهب و ${payment.amount * CONFIG.creditToGoldRate} كريدت لحسابك!`);
  } catch {}

  await interaction.reply({
    content: `✅ تم تأكيد الدفع ${code}!\n🏆 تمت إضافة ${payment.amount} ذهب و ${payment.amount * CONFIG.creditToGoldRate} كريدت لـ <@${payment.userId}>`,
    flags: MessageFlags.Ephemeral
  });
}

async function handleReset(interaction) {
  if (!isAdmin(interaction.user.id)) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('لاعب');
  const army = db.getArmy(target.id);

  if (!army) {
    return interaction.reply({
      content: `❌ ${target.username} مش عنده جيش.`,
      flags: MessageFlags.Ephemeral
    });
  }

  if (army.alliance) {
    const alliance = db.data.alliances[army.alliance];
    if (alliance) {
      alliance.members = alliance.members.filter(id => id !== target.id);
      if (alliance.leader === target.id) {
        delete db.data.alliances[army.alliance];
      }
    }
  }

  delete db.data.armies[target.id];
  db.updateEconomy();
  db.addLog('admin_reset', { admin: interaction.user.id, target: target.id });

  await interaction.reply({
    content: `✅ تم تصفير جيش ${target.username}`,
    flags: MessageFlags.Ephemeral
  });
}

async function handleResetAll(interaction) {
  if (!isAdmin(interaction.user.id)) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('confirm_reset_all')
      .setLabel('✅ تأكيد')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('cancel_reset_all')
      .setLabel('❌ إلغاء')
      .setStyle(ButtonStyle.Secondary)
  );

  const msg = await interaction.reply({
    content: '⚠️ **هل أنت متأكد من حذف جميع الجيوش؟ لا يمكن التراجع!**',
    components: [row],
    flags: MessageFlags.Ephemeral
  });

  const filter = i => i.user.id === interaction.user.id;
  const button = await msg.awaitMessageComponent({ filter, time: 15000 }).catch(() => null);

  if (!button) {
    return msg.edit({ content: '⏳ انتهى الوقت.', components: [] });
  }

  if (button.customId === 'confirm_reset_all') {
    db.data.armies = {};
    db.data.alliances = {};
    db.data.joinRequests = {};
    db.data.economy = { totalCoins: 0, totalCredits: 0, multiplier: 1.0 };
    db.data.pendingPayments = {};
    db.data.goldTransactions = [];
    db.data.logs = [];
    db.save();
    await button.update({ content: '✅ تم حذف جميع الجيوش والتحالفات.', components: [] });
  } else {
    await button.update({ content: '❌ تم إلغاء العملية.', components: [] });
  }
}

async function handleAnnouncement(interaction) {
  if (!isAdmin(interaction.user.id)) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const text = interaction.options.getString('النص');

  const embed = new EmbedBuilder()
    .setColor(0x3498DB)
    .setTitle('📢 إعلان رسمي')
    .setDescription(text)
    .setFooter({ text: `من: ${interaction.user.username}` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

async function handleGiveaway(interaction) {
  if (!isAdmin(interaction.user.id)) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const prize = interaction.options.getString('الجائزة');
  const winners = interaction.options.getInteger('الفائزين');
  const duration = interaction.options.getInteger('المدة') || 60;

  const embed = new EmbedBuilder()
    .setColor(0xF39C12)
    .setTitle('🎉 سحب/هدية!')
    .setDescription(`**الجائزة:** ${prize}\n**عدد الفائزين:** ${winners}\n**المدة:** ${duration} ثانية`)
    .setFooter({ text: 'اضغط على الزر للمشاركة' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('giveaway_enter')
      .setLabel('🎫 اشترك')
      .setStyle(ButtonStyle.Success)
  );

  const msg = await interaction.reply({ embeds: [embed], components: [row] });

  const participants = new Set();
  const filter = i => i.customId === 'giveaway_enter';
  const collector = msg.createMessageComponentCollector({ filter, time: duration * 1000 });

  collector.on('collect', async (i) => {
    participants.add(i.user.id);
    await i.reply({
      content: '✅ تم تسجيل مشاركتك!',
      flags: MessageFlags.Ephemeral
    });
  });

  collector.on('end', async () => {
    const participantList = Array.from(participants);
    const shuffled = shuffleArray(participantList);
    const winnersList = shuffled.slice(0, Math.min(winners, shuffled.length));

    const resultEmbed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('🏆 نتائج السحب!')
      .addFields(
        { name: '🎁 الجائزة', value: prize, inline: true },
        { name: '👥 عدد المشاركين', value: `${participants.size}`, inline: true }
      );

    if (winnersList.length > 0) {
      resultEmbed.addFields({
        name: '🏅 الفائزون',
        value: winnersList.map(id => `<@${id}>`).join('\n'),
        inline: false
      });
    } else {
      resultEmbed.setDescription('😔 مفيش فائزين!');
    }

    await msg.edit({ embeds: [resultEmbed], components: [] });
  });
}

async function handleBlacklist(interaction) {
  if (!isAdmin(interaction.user.id)) {
    return interaction.reply({
      content: '❌ ليس لديك صلاحية.',
      flags: MessageFlags.Ephemeral
    });
  }

  const target = interaction.options.getUser('لاعب');
  const reason = interaction.options.getString('سبب') || 'لا يوجد سبب';

  if (!db.data.blacklist) db.data.blacklist = [];

  if (db.data.blacklist.includes(target.id)) {
    db.data.blacklist = db.data.blacklist.filter(id => id !== target.id);
    db.save();
    return interaction.reply({
      content: `✅ تم فك حظر ${target.username}`,
      flags: MessageFlags.Ephemeral
    });
  }

  db.data.blacklist.push(target.id);
  db.save();
  db.addLog('blacklist', { admin: interaction.user.id, target: target.id, reason });

  await interaction.reply({
    content: `⛔ تم حظر ${target.username}\nسبب: ${reason}`,
    flags: MessageFlags.Ephemeral
  });
}

// ════════════════════════════════════════════════════════════════════
//  PREFIX COMMANDS
// ════════════════════════════════════════════════════════════════════
const prefixCommands = {};

function registerPrefix(name, fn) {
  prefixCommands[name] = fn;
}

registerPrefix('مساعدة', async (msg, args) => {
  const embed = new EmbedBuilder()
    .setColor(0x3498DB)
    .setTitle('📖 دليل لعبة الجيوش')
    .setThumbnail(client.user.displayAvatarURL())
    .addFields(
      { name: '🚀 البداية', value: '`!بدء [اسم]` — إنشاء جيش\n`!p` أو `!ملفي` — عرض معلوماتك\n`!توب` — أقوى الجيوش', inline: false },
      { name: '⚔️ القتال', value: '`!غارة [عدد]` — غارة على الوحوش\n`!هجوم @لاعب` — هجوم على لاعب', inline: false },
      { name: '🛒 المتجر', value: '`!متجر` — قائمة المشتريات\n`!شراء [عنصر] [كمية]` — شراء سريع', inline: false },
      { name: '💰 الموارد', value: '`!جمع` — جمع دخل المناجم\n`!مخزون` — عرض مخزونك\n`!اقتصاد` — حالة الاقتصاد', inline: false },
      { name: '🏆 الذهب والكريدت', value: '`!ذهب [كمية]` — شراء ذهب\n`!كريدت` — عرض الرصيد\n`!تحويل` — تحويل العملات', inline: false },
      { name: '🤝 التحالفات', value: '`!تحالف [اسم]` — إنشاء\n`!انضمام [اسم]` — طلب\n`!الطلبات` `!قبول` `!رفض`', inline: false },
      { name: '💡 الأوامر السلاش', value: 'استخدم `/` لعرض جميع أوامر السلاش العربية', inline: false },
      { name: '💰 تحويل بين الأعضاء', value: '`c @لاعب [المبلغ]` — تحويل عملات لعضو آخر', inline: false }
    )
    .setFooter({ text: 'البادئات: ! و $ | استخدم / للأوامر السلاش' });

  await msg.reply({ embeds: [embed] });
});

registerPrefix('شراء', async (msg, args) => {
  const army = db.getArmy(msg.author.id);
  if (!army) return msg.reply('❌ مش عندك جيش.');

  if (!args[0]) {
    const embed = new EmbedBuilder()
      .setColor(0x3498DB)
      .setTitle('🛒 متجر سريع')
      .setDescription(`💰 رصيدك: ${formatNumber(army.coins)} عملة | 💳 ${formatNumber(army.credits || 0)} كريدت`)
      .addFields(
        { name: '🪖 جنود', value: '`!شراء جندي [كمية]` — 3 عملة/جندي', inline: true },
        { name: '🏗️ مباني', value: '`!شراء قاعدة` — 10,000 عملة', inline: true },
        { name: '⛏️ منجم', value: '`!شراء منجم [كمية]` — 500,000 عملة', inline: true },
        { name: '🚀 صواريخ', value: '`!شراء صاروخ [كمية]` — 5,000 عملة', inline: true },
        { name: '✨ مميزات', value: '`!شراء درع` — 50,000 عملة', inline: true },
        { name: '💡 أمثلة', value: '`!شراء جندي 100`\n`!شراء منجم 5`' }
      );
    return msg.reply({ embeds: [embed] });
  }

  const item = args[0];
  const quantity = parseInt(args[1]) || 1;

  const items = db.data.shop.items;

  let foundItem = null;
  for (const [key, value] of Object.entries(items)) {
    if (value.name === item || key === item) {
      foundItem = value;
      break;
    }
  }

  if (!foundItem) {
    return msg.reply('❌ عنصر غير معروف. استخدم `!شراء` لعرض القائمة.');
  }

  const totalCost = (foundItem.price || 0) * quantity;
  const totalCostCredit = (foundItem.priceCredit || 0) * quantity;

  if (totalCost > 0 && army.coins < totalCost) {
    return msg.reply(`❌ محتاج ${formatNumber(totalCost)} عملة. عندك ${formatNumber(army.coins)}`);
  }

  if (totalCostCredit > 0 && (army.credits || 0) < totalCostCredit) {
    return msg.reply(`❌ محتاج ${formatNumber(totalCostCredit)} كريدت. عندك ${formatNumber(army.credits || 0)}`);
  }

  army.coins -= totalCost;
  army.credits = (army.credits || 0) - totalCostCredit;

  applyItemToArmy(army, foundItem, quantity);

  db.updateEconomy();
  db.addLog('prefix_buy', { userId: msg.author.id, item: foundItem.id, quantity, cost: totalCost, costCredit: totalCostCredit });

  await msg.reply(`✅ تم شراء ${quantity}x ${foundItem.emoji} ${foundItem.name}!\n💰 التكلفة: ${totalCost > 0 ? formatNumber(totalCost) + ' عملة' : ''} ${totalCostCredit > 0 ? formatNumber(totalCostCredit) + ' كريدت' : ''}`);
});

registerPrefix('p', async (msg, args) => {
  const target = msg.mentions.users.first() || msg.author;
  const army = db.getArmy(target.id);
  if (!army) {
    return msg.reply(target.id === msg.author.id ? '❌ مش عندك جيش.' : `❌ ${target.username} مش عنده جيش.`);
  }

  const power = calcPower(army);
  const defense = calcDefense(army);
  const total = totalSoldiers(army);

  const embed = new EmbedBuilder()
    .setColor(0xFFD700)
    .setTitle(`⚔️ جيش ${army.name}`)
    .setThumbnail(target.displayAvatarURL({ dynamic: true, size: 256 }))
    .addFields(
      { name: '💰 العملات', value: `**${formatNumber(army.coins)}**`, inline: true },
      { name: '💳 الكريدت', value: `**${formatNumber(army.credits || 0)}**`, inline: true },
      { name: '🏆 الذهب', value: `**${army.gold || 0}**`, inline: true },
      { name: '⚡ القوة', value: `**${formatNumber(power)}**`, inline: true },
      { name: '🛡️ الدفاع', value: `**${formatNumber(defense)}**`, inline: true },
      { name: '🪖 الجنود', value: `**${formatNumber(total)}**`, inline: true },
      { name: '📈 المستوى', value: `**${getLevel(army.xp)}**`, inline: true }
    )
    .setTimestamp();

  await msg.reply({ embeds: [embed] });
});

registerPrefix('توب', async (msg, args) => {
  const armies = Object.values(db.data.armies);
  if (!armies.length) return msg.reply('❌ مفيش جيوش لسه.');

  const sorted = armies.sort((a, b) => calcPower(b) - calcPower(a)).slice(0, 10);
  const medals = ['🥇', '🥈', '🥉'];

  let description = '';
  for (let i = 0; i < sorted.length; i++) {
    const army = sorted[i];
    const medal = medals[i] || `**${i + 1}.**`;
    const user = await client.users.fetch(army.id).catch(() => null);
    const username = user ? user.username : army.id;
    description += `${medal} **${army.name}** — ⚡ ${formatNumber(calcPower(army))} (${username})\n`;
  }

  const embed = new EmbedBuilder()
    .setColor(0xFFD700)
    .setTitle('🏆 أقوى 10 جيوش')
    .setDescription(description)
    .setTimestamp();

  await msg.reply({ embeds: [embed] });
});

registerPrefix('c', async (msg, args) => {
  if (!args[0] || !args[1]) {
    return msg.reply('❌ استخدم: c @لاعب [المبلغ]');
  }

  const target = msg.mentions.users.first();
  if (!target) {
    return msg.reply('❌ اذكر اللاعب بشكل صحيح.');
  }

  const amount = parseInt(args[1]);
  if (isNaN(amount) || amount < 1) {
    return msg.reply('❌ أدخل مبلغ صحيح.');
  }

  if (target.id === msg.author.id) {
    return msg.reply('❌ مينفعش تحول لنفسك.');
  }

  const army = db.getArmy(msg.author.id);
  if (!army) {
    return msg.reply('❌ مش عندك جيش.');
  }

  const targetArmy = db.getArmy(target.id);
  if (!targetArmy) {
    return msg.reply(`❌ ${target.username} مش عنده جيش.`);
  }

  if (army.coins < amount) {
    return msg.reply(`❌ مش عندك عملات كافية. عندك ${formatNumber(army.coins)} عملة.`);
  }

  const fee = Math.floor(amount * 0.05);
  const finalAmount = amount - fee;

  army.coins -= amount;
  targetArmy.coins += finalAmount;

  db.updateEconomy();
  db.addLog('transfer', { from: msg.author.id, to: target.id, amount, fee, finalAmount });

  const embed = new EmbedBuilder()
    .setColor(0x2ECC71)
    .setTitle('💰 تم التحويل!')
    .setDescription(`${msg.author.username} حول ${formatNumber(amount)} عملة لـ ${target.username}`)
    .addFields(
      { name: '💸 الرسوم', value: `**${formatNumber(fee)} عملة (5%)**`, inline: true },
      { name: '📥 المستلم', value: `**+${formatNumber(finalAmount)} عملة**`, inline: true },
      { name: '💼 رصيدك المتبقي', value: `**${formatNumber(army.coins)}**`, inline: true }
    )
    .setTimestamp();

  await msg.reply({ embeds: [embed] });
});

// ════════════════════════════════════════════════════════════════════
//  MESSAGE HANDLER
// ════════════════════════════════════════════════════════════════════
client.on('messageCreate', async (msg) => {
  if (msg.author.bot) return;

  if (db.data.blacklist && db.data.blacklist.includes(msg.author.id)) {
    return;
  }

  const content = msg.content;
  let prefix = null;

  for (const p of CONFIG.prefixes) {
    if (content.startsWith(p)) {
      prefix = p;
      break;
    }
  }

  if (!prefix) return;

  const args = content.slice(prefix.length).trim().split(/\s+/);
  const cmd = args.shift().toLowerCase();

  const command = prefixCommands[cmd];
  if (command) {
    try {
      await command(msg, args);
    } catch (e) {
      console.error('❌ خطأ في أمر البريفكس:', e);
      msg.reply('❌ حدث خطأ غير متوقع.').catch(() => {});
    }
  }
});

// ════════════════════════════════════════════════════════════════════
//  INTERACTION HANDLER
// ════════════════════════════════════════════════════════════════════
client.on('interactionCreate', async (interaction) => {
  try {
    if (db.data.blacklist && db.data.blacklist.includes(interaction.user.id)) {
      return interaction.reply({
        content: '⛔ أنت محظور من استخدام البوت.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (interaction.isButton() || interaction.isStringSelectMenu()) {
      await handleTicketInteraction(interaction);
      return;
    }

    if (interaction.isModalSubmit()) {
      await handleTicketModal(interaction);
      return;
    }

    if (interaction.isChatInputCommand()) {
      const cmd = interaction.commandName;

      switch (cmd) {
        case 'بدء': await handleStart(interaction); break;
        case 'ملفي': await handleProfile(interaction); break;
        case 'متجر': await handleShop(interaction); break;
        case 'تذكرة': await handleTicket(interaction); break;
        case 'ذهب': await handleGold(interaction); break;
        case 'كريدت': await handleCredits(interaction); break;
        case 'تحويل': await handleConvert(interaction); break;
        case 'هجوم': await handleAttack(interaction); break;
        case 'غارة': await handleRaid(interaction); break;
        case 'توب': await handleTop(interaction); break;
        case 'جمع': await handleCollect(interaction); break;
        case 'تدريب': await handleTrain(interaction); break;
        case 'يومي': await handleDaily(interaction); break;
        case 'عمل': await handleWork(interaction); break;
        case 'مبارزة': await handleDuel(interaction); break;
        case 'تحالف': await handleAlliance(interaction); break;
        case 'انضمام': await handleJoin(interaction); break;
        case 'طلبات': await handleRequests(interaction); break;
        case 'قبول': await handleAccept(interaction); break;
        case 'رفض': await handleReject(interaction); break;
        case 'ترقية': await handlePromote(interaction); break;
        case 'تخفيض': await handleDemote(interaction); break;
        case 'طرد': await handleKick(interaction); break;
        case 'خروج': await handleLeave(interaction); break;
        case 'حذف_تحالف': await handleDeleteAlliance(interaction); break;
        case 'حرب': await handleWar(interaction); break;
        case 'سلام': await handlePeace(interaction); break;
        case 'قبول_سلام': await handleAcceptPeace(interaction); break;
        case 'تحالفات': await handleAlliances(interaction); break;
        case 'اعضاء': await handleMembers(interaction); break;
        case 'مساعدة': await handleHelp(interaction); break;
        case 'مخزون': await handleInventory(interaction); break;
        case 'اعطاء': await handleGive(interaction); break;
        case 'اقتصاد': await handleEconomy(interaction); break;
        case 'شفاء': await handleHeal(interaction); break;
        case 'جدار': await handleWall(interaction); break;
        case 'تجسس': await handleSpy(interaction); break;
        case 'حماية': await handleProtection(interaction); break;
        case 'قاعدة': await handleBase(interaction); break;
        case 'عروض': await handleOffers(interaction); break;
        case 'كود': await handleCode(interaction); break;
        case 'توصيات': await handleRecommendations(interaction); break;
        case 'اضافة_عملات': await handleAddCoins(interaction); break;
        case 'اضافة_كريدت': await handleAddCredits(interaction); break;
        case 'اضافة_ذهب': await handleAddGold(interaction); break;
        case 'تأكيد_دفع': await handleConfirmPay(interaction); break;
        case 'تصفير': await handleReset(interaction); break;
        case 'تصفير_الكل': await handleResetAll(interaction); break;
        case 'اعلان': await handleAnnouncement(interaction); break;
        case 'سحب': await handleGiveaway(interaction); break;
        case 'حظر': await handleBlacklist(interaction); break;
        case 'vegon': await handleVegon(interaction); break;
        case 'تحويل_vegon': await handleTransferVegon(interaction); break;
        case 'صرف_vegon': await handleExchangeVegon(interaction); break;
        case 'توب_vegon': await handleTopVegon(interaction); break;
        case 'اضافة_vegon': await handleAddVegon(interaction); break;
        case 'خصم_vegon': await handleRemoveVegon(interaction); break;
        case 'سجل_vegon': await handleVegonLog(interaction); break;
        case 'vegon_info': await handleVegonInfo(interaction); break;
        default: {
          await interaction.reply({
            content: '❌ أمر غير معروف.',
            flags: MessageFlags.Ephemeral
          });
        }
      }
      return;
    }

  } catch (e) {
    console.error('❌ خطأ في التفاعل:', e);
    try {
      await interaction.reply({
        content: '❌ حدث خطأ غير متوقع.',
        flags: MessageFlags.Ephemeral
      });
    } catch {}
  }
});

// ════════════════════════════════════════════════════════════════════
//  READY & LOGIN
// ════════════════════════════════════════════════════════════════════
client.once('ready', async () => {
  console.log(`✅ البوت ${client.user.tag} شغال!`);
  console.log(`📊 عدد السيرفرات: ${client.guilds.cache.size}`);
  console.log(`👥 عدد اللاعبين: ${Object.keys(db.data.armies).length}`);

  try {
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
    const commands = slashCommands.map(cmd => cmd.toJSON());

    await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commands }
    );

    console.log(`✅ تم تسجيل ${commands.length} سلاش كوماند`);
  } catch (e) {
    console.error('❌ خطأ في تسجيل السلاش:', e);
  }

  client.user.setPresence({
    activities: [{
      name: '⚔️ لعبة الجيوش | !مساعدة',
      type: ActivityType.Playing
    }],
    status: 'online'
  });
});

// ─── نظام الرواتب التلقائي ───
setInterval(() => {
  try {
    for (const army of Object.values(db.data.armies)) {
      const salary = calcHourlySalary(army);
      if (salary === 0) continue;

      if (army.coins >= salary) {
        army.coins -= salary;
        army.salaryDebt = 0;
      } else {
        army.salaryDebt = (army.salaryDebt || 0) + 1;
        if (army.salaryDebt >= 2) {
          for (const type of Object.keys(army.soldiers)) {
            army.soldiers[type] = 0;
          }
          army.salaryDebt = 0;
        }
      }
    }

    const now = Date.now();
    for (const [code, payment] of Object.entries(db.data.pendingPayments)) {
      if (payment.expiresAt && now > payment.expiresAt && payment.status === 'pending') {
        delete db.data.pendingPayments[code];
      }
    }

    for (const army of Object.values(db.data.armies)) {
      if (army.protected && Date.now() > army.protectedUntil) {
        army.protected = false;
      }
      if (army.vip && Date.now() > army.vipUntil) {
        army.vip = false;
      }
    }

    db.save();
  } catch (e) {
    console.error('❌ خطأ الرواتب:', e);
  }
}, CONFIG.salaryIntervalMs);

// ════════════════════════════════════════════════════════════════════
//  ERROR HANDLING
// ════════════════════════════════════════════════════════════════════
client.on('error', (err) => {
  console.error('❌ خطأ البوت:', err);
});

process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Rejection:', err);
});

process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
});

// ════════════════════════════════════════════════════════════════════
//  LOGIN
// ════════════════════════════════════════════════════════════════════
const token = process.env.DISCORD_TOKEN;

if (!token) {
  console.error('❌ متغير DISCORD_TOKEN غير موجود');
  process.exit(1);
}

client.login(token)
  .then(() => console.log('🔑 تم تسجيل الدخول بنجاح'))
  .catch((err) => {
    console.error('❌ فشل تسجيل الدخول:', err);
    process.exit(1);
  });